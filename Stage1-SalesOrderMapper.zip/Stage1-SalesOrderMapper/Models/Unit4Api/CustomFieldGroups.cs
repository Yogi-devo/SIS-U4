﻿namespace Temp.ARFileWriter.Models.Unit4Api;

public class CustomFieldGroups;