﻿using Newtonsoft.Json;

namespace Temp.ARFileWriter.Models.Unit4Api;

public class Customer
{
    [JsonProperty("aliasName")]
    public string? AliasName { get; set; }

    [JsonProperty("companyId")]
    public string? CompanyId { get; set; }

    [JsonProperty("companyRegistrationNumber")]
    public string? CompanyRegistrationNumber { get; set; }

    [JsonProperty("countryCode")]
    public string? CountryCode { get; set; }

    [JsonProperty("customerGroupId")]
    public string? CustomerGroupId { get; set; }

    [JsonProperty("customerId")]
    public string? CustomerId { get; set; }

    [JsonProperty("customerName")]
    public string? CustomerName { get; set; }

    [JsonProperty("externalReference")]
    public string? ExternalReference { get; set; }

    [JsonProperty("invoice")]
    public Invoice? Invoice { get; set; }

    [JsonProperty("lastUpdated")]
    public LastUpdated? LastUpdated { get; set; }

    [JsonProperty("notes")]
    public string? Notes { get; set; }

    [JsonProperty("payment")]
    public Payment? Payment { get; set; }

    [JsonProperty("vatRegistrationNumber")]
    public string? VatRegistrationNumber { get; set; }

    [JsonProperty("contactPoints")]
    public List<ContactPoint>? ContactPoints { get; set; }

    [JsonProperty("customFieldGroups")]
    public CustomFieldGroups? CustomFieldGroups { get; set; }

    [JsonProperty("relatedValues")]
    public List<RelatedValue>? RelatedValues { get; set; }

    [JsonProperty("notificationMessages")]
    public NotificationMessages? NotificationMessages { get; set; }
}

