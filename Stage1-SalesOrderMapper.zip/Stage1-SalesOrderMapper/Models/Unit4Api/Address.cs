﻿using Newtonsoft.Json;

namespace Temp.ARFileWriter.Models.Unit4Api;

public class Address
{
    [JsonProperty("countryCode")]
    public string? CountryCode { get; set; }

    [JsonProperty("place")]
    public string? Place { get; set; }

    [JsonProperty("postcode")]
    public string? Postcode { get; set; }

    [JsonProperty("province")]
    public string? Province { get; set; }

    [JsonProperty("streetAddress")]
    public string? StreetAddress { get; set; }

    [JsonProperty("notificationMessages")]
    public NotificationMessages NotificationMessages { get; set; }
}