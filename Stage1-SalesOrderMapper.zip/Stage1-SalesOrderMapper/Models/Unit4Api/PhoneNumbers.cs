﻿using Newtonsoft.Json;

namespace Temp.ARFileWriter.Models.Unit4Api;

public class PhoneNumbers
{
    [JsonProperty("telephone1")]
    public string? Telephone1 { get; set; }

    [JsonProperty("telephone2")]
    public string? Telephone2 { get; set; }

    [JsonProperty("telephone3")]
    public string? Telephone3 { get; set; }

    [JsonProperty("telephone4")]
    public string? Telephone4 { get; set; }

    [JsonProperty("telephone5")]
    public string? Telephone5 { get; set; }

    [JsonProperty("telephone6")]
    public string? Telephone6 { get; set; }

    [JsonProperty("telephone7")]
    public string? Telephone7 { get; set; }

    [JsonProperty("notificationMessages")]
    public NotificationMessages? NotificationMessages { get; set; }
}