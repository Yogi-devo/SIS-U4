﻿using Newtonsoft.Json;

namespace Temp.ARFileWriter.Models.Unit4Api;

public class AdditionalContactInfo
{
    [JsonProperty("contactPerson")]
    public string? ContactPerson { get; set; }

    [JsonProperty("contactPosition")]
    public string? ContactPosition { get; set; }

    [JsonProperty("eMail")]
    public string? EMail { get; set; }

    [JsonProperty("eMailCc")]
    public string? EMailCc { get; set; }

    [JsonProperty("gtin")]
    public string? Gtin { get; set; }

    [JsonProperty("url")]
    public string? Url { get; set; }

    [JsonProperty("notificationMessages")]
    public NotificationMessages NotificationMessages { get; set; }
}