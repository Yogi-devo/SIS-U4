﻿using Newtonsoft.Json;

namespace Temp.ARFileWriter.Models.Unit4Api;

public class NotificationMessages
{
    [JsonProperty("code")]
    public long? Code { get; set; }
    
    [JsonProperty("message")]
    public string? Message { get; set; }
}