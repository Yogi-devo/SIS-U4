﻿using Newtonsoft.Json;

namespace Temp.ARFileWriter.Models.Unit4Api;

public class LastUpdated
{
    [JsonProperty("updatedAt")]
    public DateTime? UpdatedAt { get; set; }

    [JsonProperty("updatedBy")]
    public string? UpdatedBy { get; set; }

    [JsonProperty("notificationMessages")]
    public NotificationMessages NotificationMessages { get; set; }
}