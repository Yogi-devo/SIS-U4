﻿using Stage1_SalesOrderMapper.Infrastructure;

namespace Stage1_SalesOrderMapper.Models;

public class Lg04Row : IFixedWidth
{
    [FixedWidthLineField(Start = 1, Length = 25)]
    public string? Account { get; set; }
    
    [FixedWidthLineField(Start = 26, Length = 25)]
    public string? Accountable { get; set; }
    
    [FixedWidthLineField(Start = 51, Length = 160)]
    public string? Address { get; set; }
    
    [FixedWidthLineField(Start = 211, Length = 2)]
    public int? AllocationKey { get; set; }
    
    [FixedWidthLineField(Start = 213, Length = 20)]
    public decimal? Amount { get; set; }
    
    [FixedWidthLineField(Start = 233, Length = 1)]
    public int? AmountSet { get; set; }
    
    [FixedWidthLineField(Start = 234, Length = 25)]
    public string? AparId { get; set; }
    
    [FixedWidthLineField(Start = 259, Length = 25)]
    public string? AparIdRef { get; set; }
    
    [FixedWidthLineField(Start = 284, Length = 255)]
    public string? AparName { get; set; }
    
    [FixedWidthLineField(Start = 539, Length = 255)]
    public string? ArtDescr { get; set; }
    
    [FixedWidthLineField(Start = 794, Length = 25)]
    public string? Article { get; set; }
    
    [FixedWidthLineField(Start = 819, Length = 4)]
    public string? Att1Id { get; set; }
    
    [FixedWidthLineField(Start = 823, Length = 4)]
    public string? Att2Id { get; set; }
    
    [FixedWidthLineField(Start = 827, Length = 4)]
    public string? Att3Id { get; set; }
    
    [FixedWidthLineField(Start = 831, Length = 4)]
    public string? Att4Id { get; set; }
    
    [FixedWidthLineField(Start = 835, Length = 4)]
    public string? Att5Id { get; set; }
    
    [FixedWidthLineField(Start = 839, Length = 4)]
    public string? Att6Id { get; set; }
    
    [FixedWidthLineField(Start = 843, Length = 4)]
    public string? Att7Id { get; set; }
    
    [FixedWidthLineField(Start = 847, Length = 35)]
    public string? BankAccount { get; set; }
    
    [FixedWidthLineField(Start = 882, Length = 25)]
    public string? BatchId { get; set; }
    
    [FixedWidthLineField(Start = 907, Length = 25)]
    public string? Client { get; set; }
    
    [FixedWidthLineField(Start = 932, Length = 25)]
    public string? ClientRef { get; set; }
    
    // TODO write a DateTime parser instead of getting string from DB
    [FixedWidthLineField(Start = 957, Length = 8)]
    public string? ConfirmDate { get; set; } 
    
    [FixedWidthLineField(Start = 965, Length = 1)]
    public string? Control { get; set; }
    
    [FixedWidthLineField(Start = 966, Length = 20)]
    public decimal? CurAmount { get; set; }
    
    [FixedWidthLineField(Start = 986, Length = 25)]
    public string? Currency { get; set; }
    
    [FixedWidthLineField(Start = 1011, Length = 255)]
    public string? DelMetDescr { get; set; }
    
    [FixedWidthLineField(Start = 1266, Length = 255)]
    public string? DelTermDescr { get; set; }
    
    [FixedWidthLineField(Start = 1521, Length = 255)]
    public string? DelivAddr { get; set; }
    
    [FixedWidthLineField(Start = 1776, Length = 50)]
    public string? DelivAttn { get; set; }
    
    [FixedWidthLineField(Start = 1826, Length = 25)]
    public string? DelivCountr { get; set; }
    
    // TODO write a DateTime parser instead of getting string from DB
    [FixedWidthLineField(Start = 1851, Length = 8)]
    public string? DelivDate { get; set; } 
    
    [FixedWidthLineField(Start = 1859, Length = 25)]
    public string? DelivMethod { get; set; }
    
    [FixedWidthLineField(Start = 1884, Length = 25)]
    public string? DelivTerms { get; set; }
    
    [FixedWidthLineField(Start = 1909, Length = 25)]
    public string? Dim1 { get; set; }
    
    [FixedWidthLineField(Start = 1934, Length = 25)]
    public string? Dim2 { get; set; }
    
    [FixedWidthLineField(Start = 1959, Length = 25)]
    public string? Dim3 { get; set; }
    
    [FixedWidthLineField(Start = 1984, Length = 25)]
    public string? Dim4 { get; set; }
    
    [FixedWidthLineField(Start = 2009, Length = 25)]
    public string? Dim5 { get; set; }
    
    [FixedWidthLineField(Start = 2034, Length = 25)]
    public string? Dim6 { get; set; }
    
    [FixedWidthLineField(Start = 2059, Length = 25)]
    public string? Dim7 { get; set; }
    
    [FixedWidthLineField(Start = 2084, Length = 25)]
    public string? DimValue1 { get; set; }
    
    [FixedWidthLineField(Start = 2109, Length = 25)]
    public string? DimValue2 { get; set; }
    
    [FixedWidthLineField(Start = 2134, Length = 25)]
    public string? DimValue3 { get; set; }
    
    [FixedWidthLineField(Start = 2159, Length = 25)]
    public string? DimValue4 { get; set; }
    
    [FixedWidthLineField(Start = 2184, Length = 25)]
    public string? DimValue5 { get; set; }
    
    [FixedWidthLineField(Start = 2209, Length = 25)]
    public string? DimValue6 { get; set; }
    
    [FixedWidthLineField(Start = 2234, Length = 25)]
    public string? DimValue7 { get; set; }
    
    [FixedWidthLineField(Start = 2259, Length = 20)]
    public decimal? Discount { get; set; }
    
    [FixedWidthLineField(Start = 2279, Length = 20)]
    public float? DiscPercent { get; set; }
    
    [FixedWidthLineField(Start = 2299, Length = 50)]
    public string? Ean { get; set; }
    
    [FixedWidthLineField(Start = 2349, Length = 20)]
    public float? ExchRate { get; set; }
    
    [FixedWidthLineField(Start = 2369, Length = 100)]
    public string? ExtOrdRef { get; set; }
    
    [FixedWidthLineField(Start = 2469, Length = 25)]
    public string? IntruleId { get; set; }
    
    [FixedWidthLineField(Start = 2494, Length = 4)]
    public int? LineNo { get; set; }
    
    [FixedWidthLineField(Start = 2498, Length = 12)]
    public string? Location { get; set; }
    
    [FixedWidthLineField(Start = 2510, Length = 120)]
    public string? LongInfo1 { get; set; }
    
    [FixedWidthLineField(Start = 2630, Length = 120)]
    public string? LongInfo2 { get; set; }
    
    [FixedWidthLineField(Start = 2750, Length = 10)]
    public string? Lot { get; set; }
    
    [FixedWidthLineField(Start = 2760, Length = 25)]
    public string? MainAparId { get; set; }
    
    [FixedWidthLineField(Start = 2785, Length = 50)]
    public string? MarkAttention { get; set; }
    
    [FixedWidthLineField(Start = 2835, Length = 25)]
    public string? MarkCtryCd { get; set; }
    
    [FixedWidthLineField(Start = 2860, Length = 255)]
    public string? Markings { get; set; }
    
    // TODO write a DateTime parser instead of getting string from DB
    [FixedWidthLineField(Start = 3115, Length = 8)]
    public string? ObsDate { get; set; }
    
    // TODO write a DateTime parser instead of getting string from DB
    [FixedWidthLineField(Start = 3123, Length = 8)]
    public string? OrderDate { get; set; }
    
    [FixedWidthLineField(Start = 3131, Length = 15)]
    public long? OrderId { get; set; }
    
    [FixedWidthLineField(Start = 3146, Length = 2)]
    public string? OrderType { get; set; }
    
    [FixedWidthLineField(Start = 3148, Length = 2)]
    public string? PayMethod { get; set; }
    
    [FixedWidthLineField(Start = 3150, Length = 4)]
    public string? PayTempId { get; set; }
    
    [FixedWidthLineField(Start = 3154, Length = 6)]
    public int? Period { get; set; }
    
    [FixedWidthLineField(Start = 3160, Length = 40)]
    public string? Place { get; set; }
    
    [FixedWidthLineField(Start = 3200, Length = 40)]
    public string? Province { get; set; }
    
    [FixedWidthLineField(Start = 3240, Length = 25)]
    public string? RelValue { get; set; }
    
    [FixedWidthLineField(Start = 3265, Length = 25)]
    public string? Responsible { get; set; }
    
    [FixedWidthLineField(Start = 3290, Length = 25)]
    public string? Responsible2 { get; set; }
    
    [FixedWidthLineField(Start = 3315, Length = 8)]
    public int? SequenceNo { get; set; }
    
    [FixedWidthLineField(Start = 3323, Length = 8)]
    public int? SequenceRef { get; set; }
    
    [FixedWidthLineField(Start = 3331, Length = 20)]
    public string? SerialNo { get; set; }
    
    [FixedWidthLineField(Start = 3351, Length = 60)]
    public string? ShortInfo { get; set; }
    
    [FixedWidthLineField(Start = 3411, Length = 1)]
    public string? Status { get; set; }
    
    [FixedWidthLineField(Start = 3412, Length = 50)]
    public string? SupArticle { get; set; }
    
    [FixedWidthLineField(Start = 3462, Length = 25)]
    public string? TaxCode { get; set; }
    
    [FixedWidthLineField(Start = 3487, Length = 25)]
    public string? TaxSystem { get; set; }
    
    [FixedWidthLineField(Start = 3512, Length = 8)]
    public int? TemplateId { get; set; }
    
    [FixedWidthLineField(Start = 3520, Length = 25)]
    public string? TermsId { get; set; }
    
    [FixedWidthLineField(Start = 3545, Length = 100)]
    public string? Text1 { get; set; }
    
    [FixedWidthLineField(Start = 3645, Length = 100)]
    public string? Text2 { get; set; }
    
    [FixedWidthLineField(Start = 3745, Length = 100)]
    public string? Text3 { get; set; }
    
    [FixedWidthLineField(Start = 3845, Length = 100)]
    public string? Text4 { get; set; }
    
    [FixedWidthLineField(Start = 3945, Length = 2)]
    public string? TransType { get; set; }
    
    [FixedWidthLineField(Start = 3947, Length = 3)]
    public string? UnitCode { get; set; }
    
    [FixedWidthLineField(Start = 3950, Length = 255)]
    public string? UnitDescr { get; set; }
    
    [FixedWidthLineField(Start = 4205, Length = 20)]
    public float? UnitPrice { get; set; }
    
    [FixedWidthLineField(Start = 4225, Length = 20)]
    public float? Value1 { get; set; }
    
    [FixedWidthLineField(Start = 4245, Length = 15)]
    public long? VoucherRef { get; set; }
    
    [FixedWidthLineField(Start = 4260, Length = 25)]
    public string? VoucherType { get; set; }
    
    [FixedWidthLineField(Start = 4285, Length = 25)]
    public string? Warehouse { get; set; }
    
    [FixedWidthLineField(Start = 4310, Length = 15)]
    public string? ZipCode { get; set; }

    public string? PartnerCode { get; set; }

    public string? Intake { get; set; }

    public string? City { get; set; }

    public DefaultConfig GetDefaultConfig(int structureTypeId)
        => new DefaultConfig();
}