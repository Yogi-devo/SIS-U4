﻿using CsvHelper;
using Dapper;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.WebJobs;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Stage1_SalesOrderMapper.Config;
using Stage1_SalesOrderMapper.Infrastructure;
using Stage1_SalesOrderMapper.Interfaces;
using Stage1_SalesOrderMapper.Models;
using System.Globalization;
using Temp.ARFileWriter.Models.Unit4Api;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Stage1_SalesOrderMapper;

public class PaymentsFunction(IConfiguration configuration, ILogger<PaymentsFunction> logger, IUnit4ApiService unit4ApiService, Interfaces.ISftpClient sftpClient, IOptions<FeatureFlags> featureFlags)
{
        [Singleton]
    [Function("Stage1_SalesOrderMapper")]
    public async Task Run([TimerTrigger("%FunctionSchedule%", RunOnStartup = true)] TimerInfo myTimer)
    {
        if (!featureFlags.Value.FunctionEnabled)
        {
            logger.LogInformation("FunctionEnabled set to false. No-opping.");
        }
        else
        {

            try
            {
                List<Lg04Row> lg04Output = [];

                var batchIdLg40 = $"SLG04_{DateTime.Now:HHmmss}";

                await using var sqlConnection = new SqlConnection(configuration.GetValue<string>("thesis_dbconnectionstring"));

                var getSalesOrdersSql = File.ReadAllText("SqlQueries/GetSalesOrders.sql");
                var log04Rows = (await sqlConnection.QueryAsync<Lg04Row>(getSalesOrdersSql)).ToList();

                if (log04Rows.Count > 0)
                {
                    // TODO shift to mapper
                    foreach (var row in log04Rows.Where(x => !string.IsNullOrWhiteSpace(x.AparId)))
                    {
                        row.ArtDescr = $"{row.ArtDescr}";

                        // create customer
                        var studentLeadId = row.AparId.Length <= 10 ? row.AparId : row.AparId?[0..9];
                        studentLeadId = studentLeadId.TrimStart('0');
                        var customer = new Customer
                        {
                            AliasName = studentLeadId,
                            CustomerId = studentLeadId,
                            CompanyId = row.Client,
                            CountryCode = row.MarkCtryCd,
                            CustomerGroupId = row.PartnerCode.Equals("Self", StringComparison.OrdinalIgnoreCase) ? "10" : "14",
                            CustomerName = row.AparName,
                            ExternalReference = studentLeadId,
                            Invoice = new Invoice
                            {
                                HeadOffice = studentLeadId,
                                PaymentTermsId = "4"
                            },
                            Payment = new Payment
                            {
                                DebtCollectionCode = row.PartnerCode.Equals("Self", StringComparison.OrdinalIgnoreCase) ? "01" : "02",
                                Status = "Active"
                            },
                            ContactPoints =
                            [
                                new()
                        {
                            AdditionalContactInfo = new AdditionalContactInfo
                            {
                                EMail = $"{studentLeadId}@globalbanking.ac.uk"
                            },
                            Address = new Address
                            {
                                CountryCode = row.DelivCountr,
                                Place = row.City,
                                Postcode = row.ZipCode,
                                StreetAddress = row.DelivAddr
                            },
                            PhoneNumbers = new PhoneNumbers
                            {
                                Telephone1 = ""
                            }
                        }
                            ],
                            RelatedValues = [
                                new() { RelationId = "ZB28", Value = row.Dim4.Trim() },
                            new() { RelationId = "ZV24", Value = row.Intake }
                            ]
                        };
                        await unit4ApiService.CreateCustomerAsync(customer);

                        // header
                        lg04Output.Add(new Lg04Row
                        {
                            
                        });

                        // line
                        lg04Output.Add(row);
                    }

                    var fixedLengthItems = new FixedWidthLinesProvider<Lg04Row>().Write(lg04Output);

                    var filename = $"{batchIdLg40}.txt";
                    File.WriteAllLines(filename, fixedLengthItems);

                    // TODO debug
                    using var writer = new StreamWriter($"{batchIdLg40}.csv");
                    using var csv = new CsvWriter(writer, CultureInfo.InvariantCulture);
                    csv.WriteHeader<Lg04Row>();
                    csv.NextRecord();
                    csv.WriteRecords(lg04Output);

                    var salesOrdersCompleteMessage = $"Finished writing sales order file {filename}";
                    logger.LogInformation(salesOrdersCompleteMessage);
                    Console.WriteLine(salesOrdersCompleteMessage);

                    sftpClient.UploadFile(filename, filename);
                }
                else
                {
                    var noSalesOrdersMessage = "No sales orders to process.";
                    logger.LogInformation(noSalesOrdersMessage);
                    Console.WriteLine(noSalesOrdersMessage);
                }

                var batchIdGl07 = $"RGL07_{DateTime.Now:HHmmss}";

                var getStudentRemittancesSql = File.ReadAllText("SqlQueries/GetStudentRemittances.sql");
                var gl07Rows = (await sqlConnection.QueryAsync<Gl07Row>(getStudentRemittancesSql)).ToList();

                var random = new Random();

                if (gl07Rows?.Count > 0)
                {
                    List<Gl07Row> gl07Output = [];

                    // TODO shift to mapper
                    foreach (var row in gl07Rows)
                    {
                        row.Description = $"{row.Description}";

                        // create customer if not exists
                        var studentLeadId = row.AparId?.Length <= 10 ? row.AparId : row.AparId?[0..9];
                        studentLeadId = studentLeadId.TrimStart('0');
                        row.AparId = studentLeadId;

                        // line
                        gl07Output.Add(row);
                    }

                    var fixedLengthItems = new FixedWidthLinesProvider<Gl07Row>().Write(gl07Output);

                    var filename = $"{batchIdGl07}.txt";
                    File.WriteAllLines(filename, fixedLengthItems);

                    var remittancesCompleteMessage = $"Finished writing remittances file {filename}";
                    logger.LogInformation(remittancesCompleteMessage);
                    Console.WriteLine(remittancesCompleteMessage);

                    // TODO debug
                    using var writer = new StreamWriter($"{batchIdGl07}.csv");
                    using var csv = new CsvWriter(writer, CultureInfo.InvariantCulture);
                    csv.WriteHeader<Gl07Row>();
                    csv.NextRecord();
                    csv.WriteRecords(gl07Output);

                    sftpClient.UploadFile(filename, filename);
                }
                else
                {
                    var noRemittancesMessage = "No remittances to process.";
                    logger.LogInformation(noRemittancesMessage);
                    Console.WriteLine(noRemittancesMessage);
                }

                var processCompletedMessage = "Sales order and remittances processing complete.";
                logger.LogInformation(processCompletedMessage);
                Console.WriteLine(processCompletedMessage);
            }
            catch (Exception ex)
            {
                var exceptionMessage = ex.Message;
                logger.LogCritical(exceptionMessage, ex);
                Console.Error.WriteLine(exceptionMessage);
            }
        }
    }
}