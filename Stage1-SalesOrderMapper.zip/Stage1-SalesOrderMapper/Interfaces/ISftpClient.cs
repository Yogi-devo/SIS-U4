﻿namespace Stage1_SalesOrderMapper.Interfaces;

public interface ISftpClient
{
    void UploadFile(string sourceFilePath, string targetFilePath);
}