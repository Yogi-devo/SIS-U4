﻿using Temp.ARFileWriter.Models.Unit4Api;

namespace Stage1_SalesOrderMapper.Interfaces;

public interface IUnit4ApiService
{
    Task CreateCustomerAsync(Customer customer);
}