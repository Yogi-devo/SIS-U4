﻿using Gbs.StudentManagement.Common.Logging;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Stage1_SalesOrderMapper.Config;
using Stage1_SalesOrderMapper.Interfaces;
using Stage1_SalesOrderMapper.Middleware;
using Stage1_SalesOrderMapper.Services;

/* TODO
 * 1. Update 'TransferredToUnit4' flag.
 * 2. Deploy/run in prod TEMPORARILY USING PREVIEW U4 API
 * 3. Make sure Thesis.LookupApi values are setup in prod
 * 4. Generate new Order IDs for remittances derived from TL ID
 */

var host = new HostBuilder()
    .ConfigureFunctionsWorkerDefaults(c => c.UseMiddleware<SingletonMiddleware>())
    .ConfigureServices((ctx, services) =>
    {
        new ConfigurationBuilder()
            .AddEnvironmentVariables()
            .Build();
        
        services.AddGBSLogger();

        services.AddTransient<IUnit4ApiService, Unit4ApiService>();
        services.AddTransient<ISftpClient, Unit4SftpClient>();

        services.AddOptions<FeatureFlags>()
        .Configure<IConfiguration>((settings, configuration) =>
        {
            configuration.GetSection(nameof(FeatureFlags)).Bind(settings);
        });

        services.AddOptions<SftpConfig>()
        .Configure<IConfiguration>((settings, configuration) =>
        {
            configuration.GetSection(nameof(SftpConfig)).Bind(settings);
        });

        // services.AddSingleton<IHttpRequestMessageFactory, CookieMessageFactory>();
        // services.AddSingleton<IAuthenticateService<CookieInfo>, AuthenticateCookieService>();
        // services.AddSingleton<IThesisApiService, ThesisApiService>();
        // services.AddSingleton<IThesisTokenService, ThesisTokenService>();
        // services.AddSingleton<ITokenService<CookieInfo>,TokenService<CookieInfo>>();
        // services.Configure<ThesisConfig>(configuration.GetSection("ThesisConfig"));
        // services.AddHttpClient();
    })
    .Build();

host.Run();