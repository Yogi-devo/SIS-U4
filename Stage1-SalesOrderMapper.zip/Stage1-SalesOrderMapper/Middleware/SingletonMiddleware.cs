﻿using System.Reflection;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Middleware;
using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Logging;

namespace Stage1_SalesOrderMapper.Middleware;

public class SingletonMiddleware : IFunctionsWorkerMiddleware
{
    static readonly SemaphoreSlim Mutex = new(1);

    public async Task Invoke(FunctionContext context, FunctionExecutionDelegate next)
    {
        var workerAssembly = Assembly.GetExecutingAssembly();
        var entryPointParts = context.FunctionDefinition.EntryPoint.Split(".");
        var workerTypeName = string.Join(".", entryPointParts[..^1]);
        var workerFunctionName = entryPointParts.Last();

        var workerType = workerAssembly.GetType(workerTypeName);
        var workerFunction = workerType?.GetMethod(workerFunctionName);

        if (workerFunction?.GetCustomAttribute<SingletonAttribute>() is not null)
        {
            var logger = context.GetLogger<SingletonMiddleware>();

            logger.LogTrace($"Singleton invocation '{context.InvocationId}' waiting for semaphore...");
            await Mutex.WaitAsync();
            logger.LogTrace($"Singleton invocation '{context.InvocationId}' entered sempahore");

            try
            {
                await next(context);
                Mutex.Release();
                logger.LogTrace($"Singleton invocation '{context.InvocationId}' released sempahore");
            }
            catch (Exception)
            {
                Mutex.Release();
                logger.LogTrace($"Singleton invocation '{context.InvocationId}' released sempahore");
                throw;
            }
        }
        else
        {
            await next(context);
        }
    }
}