﻿namespace Stage1_SalesOrderMapper.Config;

public class SftpConfig
{
    public required string Hostname { get; set; }
    public int Port { get; set; } = 22;
    public required string Username { get; set; }
    public required string Password { get; set; }
}
