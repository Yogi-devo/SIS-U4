﻿namespace Stage1_SalesOrderMapper.Config;

public class FeatureFlags
{
    public bool FunctionEnabled { get; set; }
}
