﻿using Microsoft.Extensions.Options;
using Renci.SshNet;
using Stage1_SalesOrderMapper.Config;

namespace Stage1_SalesOrderMapper.Services;

public class Unit4SftpClient(IOptions<SftpConfig> sftpConfig) : Interfaces.ISftpClient
{
    public void UploadFile(string sourceFilePath, string targetFilePath)
    {
        var settings = sftpConfig.Value;
        using var sftpClient = new SftpClient(settings.Hostname, settings.Port, settings.Username, settings.Password);
        sftpClient.Connect();
        using var fileStream = File.OpenRead(sourceFilePath);
        sftpClient.UploadFile(fileStream, targetFilePath);
    }
}