﻿using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Stage1_SalesOrderMapper.Interfaces;
using System.Net;
using System.Net.Http.Headers;
using System.Text;
using Temp.ARFileWriter.Models.Unit4Api;

namespace Stage1_SalesOrderMapper.Services;

public class Unit4ApiService : IUnit4ApiService
{
    private static HttpClient SharedHttpClient;

    private readonly IConfiguration _configuration;

    public Unit4ApiService(IConfiguration configuration)
    {
        SharedHttpClient = new()
        {
            BaseAddress = new Uri(configuration.GetValue<string>("Unit4Api:BaseUrl"))
        };

        var username = configuration.GetValue<string>("Unit4Api:Username");
        var password = configuration.GetValue<string>("Unit4Api:Password");
        var basicAuthHeaderValue = ASCIIEncoding.ASCII.GetBytes($"{username}:{password}");
        SharedHttpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", Convert.ToBase64String(basicAuthHeaderValue));
        
        _configuration = configuration;
    }

    public async Task CreateCustomerAsync(Customer customer)
    {
        var customerExists = await DoesCustomerExistAsync(customer.CustomerId);
        if (!customerExists)
        {
            var body = new StringContent(
                JsonConvert.SerializeObject(customer),
                Encoding.UTF8,
                "application/json"
            );

            using var response = await SharedHttpClient.PostAsync("customers", body);

            try
            {
                response.EnsureSuccessStatusCode();
            }
            catch (Exception ex)
            {
                var responseBody = await response.Content.ReadAsStringAsync();
                throw new HttpRequestException($"Invalid response status code received from Unit4 API get student: {response.StatusCode}. Response body: {responseBody}; request body {await body.ReadAsStringAsync()}");
            }
        }
    }

    private static async Task<bool> DoesCustomerExistAsync(string customerId)
    {
        using var response = await SharedHttpClient.GetAsync($"customers/{customerId}");
        
        if (response.IsSuccessStatusCode)
            return true;
        if (response.StatusCode == HttpStatusCode.NotFound)
            return false;

        var responseBody = response.Content.ReadAsStringAsync();
        throw new HttpRequestException($"Invalid response status code received from Unit4 API get student: {response.StatusCode}. Response body: {responseBody}");
    }
}