﻿
using MailKit.Net.Smtp;
using MimeKit;
using System.Text;
using Microsoft.Extensions.Configuration;
using Azure.Storage.Blobs;


namespace MapperFunction.Services
{
    public class MailService
    {

        private readonly IConfiguration _configuration;
        
        public MailService(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public async Task<bool> SendEmailAsync(string subject, string? body)
        {
            try
            {
                var recipientEmails = _configuration["Mail:RecipientEmails"]
                         .Split(',', StringSplitOptions.RemoveEmptyEntries)
                         .Select(email => email.Trim())
                         .ToList();
                
                var emailSettings = _configuration.GetSection("EmailSettings");
                string mailServer = _configuration["Mail:MailServer"];// "smtp.office365.com";
                int mailPort = int.Parse(_configuration["Mail:MailPort"]);// 587; 
                string senderEmail = _configuration["Mail:SenderEmail"];// "unit4logs@geduservices.com";
                string senderPassword = _configuration["Mail:SenderPassword"];// "K!928435808558ac";

                string storageConnectionString = _configuration["Storage:StorageAccountConnectionString"];
                string containerName = _configuration["Log:LogFileContainer"];
                string blobFileName = $"{DateTime.Now:yyyyMMdd}_studentError.log"; 

                string fileContent = await GetBlobFileContentAsync(storageConnectionString, containerName, blobFileName);

                if (string.IsNullOrEmpty(fileContent))
                {
                    return false;
                }
                
                var emailMessage = new MimeMessage();
                emailMessage.From.Add(new MailboxAddress("Unit4 Mapper Service", senderEmail));
                
                foreach (var email in recipientEmails)
                {
                    emailMessage.To.Add(new MailboxAddress("", email));
                }
                emailMessage.Subject = subject;

                var multipart = new Multipart("mixed");
                // Add the email body
                var textPart = new TextPart("html") { Text = body };
                multipart.Add(textPart);
                
                if (!string.IsNullOrEmpty(fileContent))
                {
                    var attachment = new MimePart("text", "plain")
                    {
                        Content = new MimeContent(new MemoryStream(Encoding.UTF8.GetBytes(fileContent))),
                        ContentDisposition = new ContentDisposition(ContentDisposition.Attachment),
                        ContentTransferEncoding = ContentEncoding.Base64,
                        FileName = blobFileName
                    };
                    multipart.Add(attachment);
                }

                emailMessage.Body = multipart;

                using var smtpClient = new SmtpClient();
                await smtpClient.ConnectAsync(mailServer, mailPort, MailKit.Security.SecureSocketOptions.StartTls);
                await smtpClient.AuthenticateAsync(senderEmail, senderPassword);
                await smtpClient.SendAsync(emailMessage);
                await smtpClient.DisconnectAsync(true);

                return true;
            }
            catch
            {
                return false;
            }
        }

        private async Task<string> GetBlobFileContentAsync(string connectionString, string containerName, string blobName)
        {
            try
            {
                var blobServiceClient = new BlobServiceClient(connectionString);
                var blobContainerClient = blobServiceClient.GetBlobContainerClient(containerName);
                var blobClient = blobContainerClient.GetBlobClient(blobName);

                if (await blobClient.ExistsAsync())
                {
                    var response = await blobClient.DownloadContentAsync();
                    return response.Value.Content.ToString();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error in retrieving blob file: {ex.Message}");
            }
            return string.Empty;
        }
    }

}

