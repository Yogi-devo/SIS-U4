﻿using MapperFunction.Interfaces;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System.Net.Http.Headers;
using System.Net;
using System.Text;
using MapperFunction.Models.Unit4Api;
using MapperFunction.Models.AnthoApi;
using System.Net.Http.Json;
using MapperFunction.Models;
using CsvHelper;
using MapperFunction.Infrastructure;
using System.Globalization;
using ISftpClient = MapperFunction.Interfaces.ISftpClient;
using Azure.Storage.Blobs;
using MapperFunction.Config;
using Microsoft.Extensions.Options;
using IbanNet;
using System.Text.RegularExpressions;
using Azure.Storage.Blobs.Specialized;

namespace MapperFunction.Services
{
    public class Unit4ApiService : IUnit4ApiService
    {
        private static HttpClient SharedHttpClient;
        private readonly ISftpClient _sftpClient;
        private readonly IConfiguration _configuration;
        private readonly Lg04Values _lg04Values;
        private readonly Creden _creden;
        private readonly string _u4authToken;
        private readonly MailService _mailService;
        public Unit4ApiService(IConfiguration configuration, ISftpClient sftpClient, IOptions<Gl07Values> gl07Values, IOptions<Lg04Values> lg04Values, IOptions<Creden> creden, MailService mailService)
        {
            SharedHttpClient = new HttpClient
            {
                BaseAddress = new Uri(configuration.GetValue<string>("Unit4Api:BaseUrl"))
            };

            if (!SharedHttpClient.BaseAddress.AbsoluteUri.EndsWith("/"))
            {
                SharedHttpClient.BaseAddress = new Uri(SharedHttpClient.BaseAddress.AbsoluteUri + "/");
            }
            _configuration = configuration;
            _sftpClient = sftpClient;
            _lg04Values = lg04Values.Value;
            _creden = creden.Value;
            _mailService = mailService;
            var targetFilePath = _configuration["SftpConfig:Hostname"];

            BlobServiceClient blobServiceClient = new BlobServiceClient(_configuration["Storage:StorageAccountConnectionString"]);
            BlobContainerClient logFileContainer = blobServiceClient.GetBlobContainerClient(_configuration["Log:LogFileContainer"]);
            _u4authToken = Convert.ToBase64String(Encoding.UTF8.GetBytes($"{_creden.Unit4Username}:{_creden.Unit4Password}"));
        }


        /// <summary>
        /// This function check  customer in Unit4 ERP whether it already created or not.
        /// </summary>
        /// <param name="Student/CustomerId"> Providing one parameter </param>
        /// <returns>Its returning Bool value. If Customer exist in Unit4 then return true, if not then return false.</returns>
        /// <exception >Exception may occur during GET Api call</exception>
        private async Task<bool> DoesCustomerExistAsync(string customerId)
        {
            try
            {
                if (string.IsNullOrEmpty(customerId))
                {
                    throw new ArgumentException("CustomerId cannot be null or empty", nameof(customerId));
                }
                SharedHttpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", _u4authToken);

                var response = await SharedHttpClient.GetAsync($"{_configuration["Unit4Api:BaseUrl2"]}/{customerId}?companyId=US1");

                if (response.IsSuccessStatusCode)
                {
                    return true;
                }
                else if (response.StatusCode == HttpStatusCode.NotFound)
                {
                    return false;
                }
                else if (response.StatusCode == HttpStatusCode.Unauthorized)
                {
                    throw new HttpRequestException("Unauthorized access - check your API credentials.");
                }
                else
                {
                    var responseBody = await response.Content.ReadAsStringAsync();
                    throw new HttpRequestException($"Invalid response status code received from Unit4 API: {response.StatusCode}. Response body: {responseBody}");
                }
            }
            catch (Exception ex)
            {
                throw;
            }

        }


        /// <summary>
        /// This method is used for data synch purpose from anthology to Unit 4. in this method i getting data from anthology and processing it and then after send it to Unit4
        /// </summary>
        /// <param name="null">Not providing any parameter but during execution it will call this method at mapper method</param>
        /// <returns>Not returning any value with this method.</returns>
        /// <exception >Exception may occur during sending data to Unit4, its will logged in </exception>
        public async Task SyncStudentData(DateTime? lastRunTime)
        {
            BlobServiceClient blobServiceClient = new BlobServiceClient(_configuration["Storage:StorageAccountConnectionString"]);
            BlobContainerClient logFileContainer = blobServiceClient.GetBlobContainerClient(_configuration["Log:LogFileContainer"]);
            try
            {
                var finalData = await GetStudentFromAnthology(lastRunTime);
                if (finalData != null && finalData.Any())
                {
                    foreach (var studentData in finalData)
                    {
                        try
                        {
                            var exists = await DoesCustomerExistAsync(studentData.CustomerId);
                            if (!exists)
                            {
                                await CreateCustomerInUnit4(studentData);
                            }
                            else
                            {
                                await UpdateCustomerInUnit4(studentData);
                                Console.WriteLine($"Customer updated in Unit4 having CustomerId: {studentData.CustomerId}");

                                //if (!string.IsNullOrEmpty(studentData?.Payment?.BankAccount) && !string.IsNullOrEmpty(studentData?.Payment?.Iban) && !string.IsNullOrEmpty(studentData?.Payment?.Swift))
                                //{
                                //    await UpdateCustomerInUnit4(studentData);
                                //    Console.WriteLine($"Customer updated in Unit4 having CustomerId: {studentData.CustomerId}");
                                //}
                                Console.WriteLine($"Customer may already exist in Unit4 with CustomerId: {studentData.CustomerId}");
                            }
                        }
                        catch (Exception ex)
                        {
                            await LogErrorToBlob(studentData.CustomerId, logFileContainer, ex);
                            Console.WriteLine($"Error syncing student {studentData.CustomerId}: {ex.Message}");
                        }
                    }
                    string subject = "Student/Customer not added/updated in Unit4";
                    string body = "Some error or exception occurred during adding/updating the Student/Customer in Unit4, Please examine the attached file for details";
                    
                    bool emailSent = await _mailService.SendEmailAsync(subject, body);
                    if (emailSent)
                    {
                        Console.WriteLine("Email sent successfully!");
                    }
                }
            
            }
            catch (Exception ex)
            {

                await LogErrorToBlob(logFileContainer, ex);
            }

        }


        /// <summary>
        /// This method is used for validation of iban code.
        /// </summary>
        /// <param name="iban">send iban for validation purpose</param>
        /// <param name="StudentNumber">StudentNumber send as parameter for returning Log</param>
        /// <returns>return string iban if it is valid</returns>
        public string IbanValidate(string iban, string StudentNumber)
        {
            BlobServiceClient blobServiceClient = new BlobServiceClient(_configuration["Storage:StorageAccountConnectionString"]);
            BlobContainerClient logFileContainer = blobServiceClient.GetBlobContainerClient(_configuration["Log:LogFileContainer"]);
            if (!string.IsNullOrEmpty(iban)) 
            {

                try
                {
                    iban = iban.Replace(" ", string.Empty);
                    IIbanValidator validator = new IbanValidator();
                    IbanNet.ValidationResult validationResult = validator.Validate(iban);

                    if (validationResult.IsValid)
                    {
                        return iban;
                    }
                    else
                    {
                        string message = $"IBAN is not valid for StudentNumber: {StudentNumber}";
                        Exception exception = new Exception(message);
                        StudentErrorLog(logFileContainer, exception);
                        Console.WriteLine(message);
                        return null;
                    }
                }
                catch (Exception)
                {
                    throw;
                }
            }
            return null;
        }


        /// <summary>
        /// This method is used for validation of swift code.
        /// </summary>
        /// <param name="swift">send swift for validation purpose</param>
        /// <param name="StudentNumber">StudentNumber send as parameter for returning Log</param>
        /// <returns>return string swift if it is valid</returns>
        public string SwiftValidate(string swift, string StudentNumber)
        {
            BlobServiceClient blobServiceClient = new BlobServiceClient(_configuration["Storage:StorageAccountConnectionString"]);
            BlobContainerClient logFileContainer = blobServiceClient.GetBlobContainerClient(_configuration["Log:LogFileContainer"]);
            if (!string.IsNullOrEmpty(swift))
            {

                try
                {
                    swift = swift.Replace(" ", string.Empty);


                    string pattern = @"^[A-Za-z]{4}[A-Za-z]{2}[A-Za-z0-9]{2}([A-Za-z0-9]{3})?$";

                    Regex regex = new Regex(pattern);
                    if (regex.IsMatch(swift))
                    {
                        return swift; 
                    }
                    else
                    {
                        string message = $"SWIFT is not valid for StudentNumber: {StudentNumber}";
                        Exception exception = new Exception(message);
                        StudentErrorLog(logFileContainer, exception);
                        Console.WriteLine(message);
                        return null;
                    }
                }
                catch (Exception)
                {
                    throw;
                }
            }
            return null;
        }


        /// <summary>
        /// This method is used for finding Country code based on the country name.
        /// </summary>
        /// <param name="countryName"></param>
        /// <returns>string(Country code)</returns>
        public static string GetCountryCodeFromName(string countryName)
        {
            foreach (var culture in CultureInfo.GetCultures(CultureTypes.SpecificCultures))
            {
                RegionInfo region = new RegionInfo(culture.Name);
                if (region.EnglishName.Equals(countryName, StringComparison.OrdinalIgnoreCase))
                {
                    return region.TwoLetterISORegionName; 
                }
            }
            return string.Empty; 
        }


        /// <summary>
        /// This method is used for deciding Agency Id, if student is associated with any agency then it will return "AGENT" else return StudntId
        /// </summary>
        /// <param name="agencyCode">Send agencyCode for deciding agencyId</param>
        /// <param name="studentNumber">Send studentNumber for deciding agencyId</param>
        /// <returns>return string AgencyId</returns>
        public string GetAgency(string? agencyId , string studentNumber)
        {
            if (agencyId == null)
            {
                return studentNumber;
            }
            else
            {
                return agencyId;
            }            
        }


        /// <summary>
        /// Fetch the Customer/student data from Anthology ERP.
        /// </summary>
        /// <param name="null">Not providing any parameter but during execution it will call Anthology GET API which is provided by Anthology</param>
        /// <returns>It will return the List of all customer data.</returns>
        /// <exception >Exception may occur during mapping of field values of 'studentResponse' into  Customer object </exception>
        public async Task<List<Customer>> GetStudentFromAnthology(DateTime? lastRunTime)
        {
            try
            {
                BlobServiceClient blobServiceClient = new BlobServiceClient(_configuration["Storage:StorageAccountConnectionString"]);
                BlobContainerClient logFileContainer = blobServiceClient.GetBlobContainerClient(_configuration["Log:LogFileContainer"]);
                var authToken = Convert.ToBase64String(Encoding.UTF8.GetBytes($"{_creden.AnthologyUsername}:{_creden.AnthologyPassword}"));
                SharedHttpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", authToken);

                string baseUrl = _configuration["AnthologyConfig:Students"];

                if (string.IsNullOrEmpty(baseUrl))
                {
                    throw new Exception("Student BaseStudentBankAccountUrl is not configured.");
                }
                string date =  DateTime.UtcNow.ToString("yyyy-MM-dd"); // "2025 - 03 - 18T00: 00:00Z";
                string StudentfinalUrl = $"{baseUrl}{date}";
                //  string StudentfinalUrl = $@"https://sisclientapi-prod-101053.campusnexus.cloud/StudentFinanceIntegration/StudentBankAccount?key=61D09893F0F394D3F0349ED837DCEFCD60503AC65021C9B6059A2955317988F0&StudentId=90ABC" ;
               // var studentResponse = await SharedHttpClient.GetStringAsync(_configuration["AnthologyConfig:Students"]);
                var studentResponse = await SharedHttpClient.GetStringAsync(StudentfinalUrl);
                List<Student> studentApiResponse = JsonConvert.DeserializeObject<List<Student>>(studentResponse);

                if (studentApiResponse.Count > 0)
                {
                    var finalData = new List<Customer>();
                    foreach (var student in studentApiResponse)
                    {
                        try
                        {
                            string countryCode = GetCountryCodeFromName(student.Country.Name);
                            string customerGroupId = GetCustomerGroupId(student).ToString()  ;
                            string iban = IbanValidate(student.StudentBankAccounts?.FirstOrDefault()?.IbanNumber, student.StudentNumber);
                            string swift = SwiftValidate(student.StudentBankAccounts?.FirstOrDefault()?.SwiftCode, student.StudentNumber);
                            string agency = GetAgency(student.AgencyBranches.FirstOrDefault()?.AgencyBranch?.Agency?.Code, student.StudentNumber) ;

                            var customer = new Customer
                            {
                                AliasName = student.StudentNumber,
                                CustomerId = student.StudentNumber,
                                CompanyId = "US1",
                                CountryCode = countryCode,
                                CustomerGroupId = customerGroupId,
                                CustomerName = $"{student.FirstName} {student.LastName}",
                                ExternalReference = student.Id.ToString(),  
                                Invoice = new Invoice
                                {
                                    HeadOffice = agency, 
                                },
                                Payment = new Payment
                                {
                                    BankAccount = student.StudentBankAccounts?.FirstOrDefault()?.ExtendedAccountNumber,
                                    OtherAccount = student.StudentBankAccounts?.FirstOrDefault()?.NameOnAccount,
                                    Iban =  iban, 
                                    Swift = swift, 
                             
                                    Status = "Active"//
                                },
                                ContactPoints = new List<ContactPoint>
                                {
                                new ContactPoint
                                    {
                                        AdditionalContactInfo = new AdditionalContactInfo
                                        {
                                            EMail = student.EmailAddress
                                        },
                                        Address = new Address
                                        {
                                            Place = student.City,
                                            Postcode = student.PostalCode,
                                            //Province = student.Country.Name.ToString(),
                                            StreetAddress = student.StreetAddress
                                        },
                                        PhoneNumbers = new PhoneNumbers
                                        {
                                            Telephone1 = student.PhoneNumber,
                                            Telephone4 = student.WorkPhoneNumber,
                                        }
                                    }
                                },
                                RelatedValues = new List<RelatedValue>
                                {
                                    new RelatedValue
                                    {
                                        RelationId = "AJ",
                                        Value = customerGroupId
                                    }
                                }
                            };

                            finalData.Add(customer);
                        }
                        catch (Exception ex)
                        {
                            await LogErrorToBlob(student.StudentNumber.ToString(), logFileContainer, ex);
                            Console.WriteLine($"Error processing student/customer with Id: {student.StudentNumber}. Exception: {ex.Message}");
                        }
                    }
                    return finalData;
                }                
                Exception exp = new Exception($"No data found in 'Student' API response for provided Date and time {DateTime.UtcNow}");
                LogErrorToBlob(logFileContainer, exp);
                Console.WriteLine(exp);
                return new List<Customer>(); // Return empty list if no data 
            }
            catch (Exception)
            {

                throw;
            }

        }


        /// <summary>
        /// 10-> Self-Funded distance learning
        /// 13-> Self-Funded On campus
        /// 14-> Agency-Funded distance learning
        /// 15-> Agency-Funded On campus
        /// </summary>
        /// <param name="student"></param>
        /// <returns></returns>
        /// <exception cref="ArgumentNullException"></exception>
        public int GetCustomerGroupId(Student student)
        {
            try
            {
                if (student == null)
                    throw new ArgumentNullException(nameof(student));

                bool hasAgencyBranches = student.AgencyBranches != null && student.AgencyBranches.Any();
                bool isCampusDL = student.Campus != null && student.Campus.Code == "DL";

                if (hasAgencyBranches && isCampusDL)
                    return 14;
                if (hasAgencyBranches && !isCampusDL)
                    return 15;
                if (!hasAgencyBranches && isCampusDL)
                    return 10;

                return 13; // Default case: No agency branches and campus is not "DL"
            }
            catch (Exception)
            {

                throw;
            }
            
        }


        /// <summary>
        /// This function will create new Customer in Unit4 system.
        /// </summary>
        /// <param name="studentData"> Providing studentData list as parameter and during execution it will call POST API call for posting data.</param>
        /// <returns>It will return the 201 response code after successful creation of student.</returns>
        /// <exception >Exception may occur during post api call</exception>
        public async Task CreateCustomerInUnit4(Customer studentData)
        {

            BlobServiceClient blobServiceClient = new BlobServiceClient(_configuration["Storage:StorageAccountConnectionString"]);
            BlobContainerClient logFileContainer = blobServiceClient.GetBlobContainerClient(_configuration["Log:LogFileContainer"]);
            try
            {
                SharedHttpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", _u4authToken);
                var response = await SharedHttpClient.PostAsJsonAsync(_configuration["Unit4Api:BaseUrl"], studentData);

                if (!response.IsSuccessStatusCode)
                {
                    var responseBody = await response.Content.ReadAsStringAsync();
                    var exception = new Exception($"Failed to add student {studentData.CustomerId} in Unit4. Status: {response.StatusCode}, Response: {responseBody}");
                    await StudentErrorLog(logFileContainer, exception);
                    Console.WriteLine($"Error occurred when adding Customer with CustomerId: {studentData.CustomerId}. Exception: {exception}");
                    throw exception;
                }
                else
                {
                    Console.WriteLine($"Customer/Student {studentData.CustomerId} successfully added in Unit4");
                }
            }
            catch (Exception ex)
            {
                await LogErrorToBlob(logFileContainer, ex);
                throw;
            }
            
        }


        /// <summary>
        /// This function will update existing Customer in Unit4 system.
        /// </summary>
        /// <param name="studentData"> Providing studentData list as parameter and during execution it will call PATCH API call for posting data.</param>
        /// <returns>It will return the 201 response code after successful updating the student.</returns>
        /// <exception >Exception may occur during post api call</exception>
        public async Task UpdateCustomerInUnit4(Customer studentData)
        {
            BlobServiceClient blobServiceClient = new BlobServiceClient(_configuration["Storage:StorageAccountConnectionString"]);
            BlobContainerClient logFileContainer = blobServiceClient.GetBlobContainerClient(_configuration["Log:LogFileContainer"]);            
            SharedHttpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", _u4authToken);
            SharedHttpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json-patch+json"));
            try
            {
                
                var patchDocument = new[]
{
                    new { op = "replace", path = "/customerName", value = studentData.CustomerName ?? "" },
                    new { op = "replace", path = "/aliasName", value = studentData.AliasName ?? "" },                   
                    new { op = "replace", path = "/countryCode", value = studentData.CountryCode ?? "" },
                    new { op = "replace", path = "/customerGroupId", value = studentData.CustomerGroupId ?? "" },
                    new { op = "replace", path = "/externalReference", value = studentData.ExternalReference ?? "" },
                    
                    // Invoice details
                    new { op = "replace", path = "/invoice/headOffice", value = studentData.Invoice?.HeadOffice ?? "" },

                    // Payment details
                    new { op = "replace", path = "/payment/bankAccount", value = studentData.Payment?.BankAccount ?? "" },
                    new { op = "replace", path = "/payment/otherAccount", value = studentData.Payment?.OtherAccount ?? "" },
                    new { op = "replace", path = "/payment/Iban", value = studentData.Payment?.Iban ?? "" },
                    new { op = "replace", path = "/payment/Swift", value = studentData.Payment?.Swift ?? "" },
                    new { op = "replace", path = "/payment/BankClearingCode", value = studentData.Payment?.BankClearingCode ?? "" },
                    new { op = "replace", path = "/payment/status", value = "Active" },

                    // ContactPoints
                    new { op = "replace", path = "/contactPoints/0/additionalContactInfo/eMail", value = studentData.ContactPoints?.FirstOrDefault()?.AdditionalContactInfo?.EMail ?? "" },
                    new { op = "replace", path = "/contactPoints/0/address/place", value = studentData.ContactPoints?.FirstOrDefault()?.Address?.Place ?? "" },
                    new { op = "replace", path = "/contactPoints/0/address/postcode", value = studentData.ContactPoints?.FirstOrDefault()?.Address?.Postcode ?? "" },
                    new { op = "replace", path = "/contactPoints/0/address/streetAddress", value = studentData.ContactPoints?.FirstOrDefault()?.Address?.StreetAddress ?? "" },
                    new { op = "replace", path = "/contactPoints/0/phoneNumbers/telephone1", value = studentData.ContactPoints?.FirstOrDefault()?.PhoneNumbers?.Telephone1 ?? "" },
                    new { op = "replace", path = "/contactPoints/0/phoneNumbers/telephone4", value = studentData.ContactPoints?.FirstOrDefault()?.PhoneNumbers?.Telephone4 ?? "" },

                    // Related Values
                    //new { op = "replace", path = "/relatedValues/0/relationId", value = "AJ"},
                    //new { op = "replace", path = "/relatedValues/0/value", value = studentData.CustomerGroupId ?? "" }
};

                var jsonPatchContent = new StringContent(JsonConvert.SerializeObject(patchDocument), Encoding.UTF8, "application/json-patch+json");
                var response = await SharedHttpClient.PatchAsync($"{_configuration["Unit4Api:BaseUrl2"]}/{studentData.CustomerId}?companyId=US1", jsonPatchContent);
                if (!response.IsSuccessStatusCode)
                {
                    var responseBody = await response.Content.ReadAsStringAsync();
                    var exception = new Exception($"Failed to update student {studentData.CustomerId} in Unit4. Status: {response.StatusCode}, Response: {responseBody}");
                    await StudentErrorLog(logFileContainer, exception);
                    throw exception;
                }
                else
                {
                    Console.WriteLine($"Customer/Student {studentData.CustomerId} successfully updated in Unit4");
                }
            }
            catch (Exception ex)
            {
                await LogErrorToBlob(logFileContainer, ex);
                throw;
            }           
        }


        /// <summary>
        /// This method receive campus name and convert it into campus code.
        /// </summary>
        /// <param name="campusName"></param>
        /// <returns>string value</returns>
        private string GetLEGENTITY(string campusName, string? fundSource)
        {

            //string[] validFundSources = new[]
            //    {
            //        "PELL", "DLGPL", "DIRSUB", "PRIVATEL", "VAVOCREH", "2324 PEL", "DIRPLUS", "DIRUNSUB", "SEOG", "C33VB"
            //    };

            //if (!string.IsNullOrEmpty(fundSource) && validFundSources.Any(code => code.Equals(fundSource, StringComparison.OrdinalIgnoreCase)))
            //{
            //    return "KIPSIUUSA";
            //}

            //else
            //{
                return campusName?.ToLowerInvariant() switch
                {
                    "madrid" => "KIPSIUSPA",
                    "heidelberg" => "KIPSIUGER",
                    "paris" => "KIPSIUFRA",
                    "usa" => "KIPSIUUSA",
                    "florida" => "KIPSIUUSA",
                    "distance learning" => "KIPSIUUSA", 
                    _ => "KIPSIUUSA"
                };
              
        }


        /// <summary>
        /// This method receive campus name and, on the basis of campus name its calculate Currency Code.
        /// </summary>
        /// <param name="campusName"></param>
        /// <returns>string (Currency Code)</returns>
        private string GetCurrencyCode(string campusName)
        {
            try
            {
                return campusName?.ToLowerInvariant() switch
                {
                    "madrid" => "EUR",
                    "heidelberg" => "EUR",
                    "paris" => "EUR",
                    "usa" => "USD",
                    "hq" => "USD",
                    "florida" => "USD",
                    "dl" => "USD",
                    _ => "USD"
                };
            }
            catch (Exception)
            {

                throw;
            }
            
        }


        /// <summary>
        /// This method is used for evaluating Extended property.
        /// </summary>
        /// <param name="costCenter">If costCenter present then it will return as extended property value</param>
        /// <param name="campusCode">If costCenter not present then we extract extended property value on the basis of campusCode</param>
        /// <returns>return string value of extended property</returns>
        /// <exception cref="Exception"></exception>
        private string GetExtendedProperties(string? costCenter, string? campusCode, string? fundSource)
        {
            try
            {
                string[] validFundSources = new[]
                {
                    "PELL", "2324 PEL", "DLGPL", "DIRPLUS", "DIRUNSUB", "DIRSUB", "PRIVATEL", "VAVOCREH", "C33VB", "SEOG", "SEOGMAT"
                };

                if (!string.IsNullOrEmpty(fundSource) && validFundSources.Any(code => code.Equals(fundSource, StringComparison.OrdinalIgnoreCase)))
                {                    
                    return campusCode?.ToLowerInvariant() switch
                    {
                        "madrid" => "1930002",
                        "heidelberg" => "1920002",
                        "hd" => "1920002",
                        "paris" => "1940002",
                        _ => ""
                    };
                }
                else
                {
                    return campusCode?.ToLowerInvariant() switch
                    {
                        "spa" => "1930001",
                        "madrid" => "1930001",
                        "ger" => "1920001",
                        "heidelberg" => "1920001",
                        "hd" => "1920001",
                        "fra" => "1940001",
                        "paris" => "1940001",
                        "usa" => "1910001",
                        "florida" => "1910101",
                        "dl" => "1910200",
                        "hq" => "1910001",
                        _ => "1910001" // Default 
                    };
                }
            }
            catch (Exception ex)
            {
                throw new Exception("An error occurred while getting extended properties.", ex);
            }
        }


        /// <summary>
        /// This method take grade Scale Name as parameter and return its code.
        /// </summary>
        /// <param name="gradeScaleName"></param>
        /// <returns>string(Grade code)</returns>        
        public string? GetGradeScale(string gradeScaleName, string? fundSourceCode, string? transactionType)
        {

            var normalizedFundSource = fundSourceCode?.Trim().ToUpperInvariant();

            var excludedFundSources = new HashSet<string>
            {
                "PELL", "2324 PEL", "DLGPL", "DIRPLUS", "DIRSUB", "DIRUNSUB",
                "PRIVATEL", "SEOG", "SEOGMAT", "C33VB", "VAVOCREH"
            };


            if (string.Equals(normalizedFundSource, "SEOGMAT", StringComparison.OrdinalIgnoreCase))
            {
                return "HED";
            }


            // Only map grade scale if fund source is not in excluded list
            if (normalizedFundSource == null || !excludedFundSources.Contains(normalizedFundSource))
            {
                return gradeScaleName?.Trim().ToLowerInvariant() switch
                {
                    "undergraduate" => "UG",
                    "graduate" => "GRAD",
                    _ => "UG" // Fallback to UG if null or unrecognized
                };
            }

            return null; 
        }

        public string? GetcampusCode(string? campusCode, string? fundSourceCode, string? billingTransactionCode)
        {
            var normalizedFundSource = fundSourceCode?.Trim().ToUpperInvariant();
            var excludedFundSources = new HashSet<string>
            {
                "PELL", "2324 PEL", "DLGPL", "DIRPLUS", "DIRSUB", "DIRUNSUB",
                "PRIVATEL", "SEOG",  "C33VB", "VAVOCREH"
            };

            if ((normalizedFundSource == null || !excludedFundSources.Contains(normalizedFundSource)) &&
                 !string.Equals(billingTransactionCode, "CURTRAN", StringComparison.OrdinalIgnoreCase))
            {
                return campusCode;
            }
            return null;
        }

        
        /// <summary>
        /// This method find out appropriate Product code based on scenario
        /// </summary>
        /// <param name="billingTransactionCode"></param>
        /// <param name="programVersionCode"></param>
        /// <param name="transactionType"></param>
        /// <returns>string value of Product code</returns>        
        public string? GetProductCodeD3(string? billingTransactionCode, string? programVersionCode, string? transactionType, string? fundSource, string? campusCode)
        {

            var FAFundSource = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
             {
              "PELL", "2324 PEL", "DLGPL", "DIRPLUS", "DIRSUB",
              "DIRUNSUB", "PRIVATEL", "SEOG", "C33VB", "VAVOCREH"
            };

            bool isFAFundSource = !string.IsNullOrEmpty(fundSource) && FAFundSource.Contains(fundSource);

            if (string.Equals(billingTransactionCode, "TUIT", StringComparison.OrdinalIgnoreCase))
            {
                return programVersionCode ?? "APPLICANT";
            }
            else if (string.Equals(transactionType, "P", StringComparison.OrdinalIgnoreCase) ||
               string.Equals(billingTransactionCode, "CURTRAN", StringComparison.OrdinalIgnoreCase))
            {
                if (!string.IsNullOrEmpty(campusCode) &&
                    (string.Equals(campusCode, "FLORIDA", StringComparison.OrdinalIgnoreCase) ||
                     string.Equals(campusCode, "DL", StringComparison.OrdinalIgnoreCase) ||
                     string.Equals(campusCode, "HQ", StringComparison.OrdinalIgnoreCase))
                    && !string.IsNullOrEmpty(fundSource))
                {
                    string upperFundSource = fundSource.ToUpperInvariant();

                    if (upperFundSource == "PELL" || upperFundSource == "2324 PEL" || upperFundSource == "DLGPL" ||
                        upperFundSource == "DIRPLUS" || upperFundSource == "DIRSUB" ||
                        upperFundSource == "DIRUNSUB" || upperFundSource == "PRIVATEL" ||
                        upperFundSource == "SEOG" || upperFundSource == "SEOGMAT" ||
                        upperFundSource == "C33VB" || upperFundSource == "VAVOCREH")
                    {
                        return $"{upperFundSource}-USA";
                    }
                }


                else if (!string.IsNullOrEmpty(campusCode) &&
                    (string.Equals(campusCode, "HD", StringComparison.OrdinalIgnoreCase) ||
                     string.Equals(campusCode, "MADRID", StringComparison.OrdinalIgnoreCase) ||
                     string.Equals(campusCode, "PARIS", StringComparison.OrdinalIgnoreCase))
                    && string.Equals(fundSource, "SEOGMAT", StringComparison.OrdinalIgnoreCase))
                {
                    return "SEOGMAT";
                }


                else if (!string.IsNullOrEmpty(campusCode) &&
                    (string.Equals(campusCode, "HD", StringComparison.OrdinalIgnoreCase) ||
                     string.Equals(campusCode, "MADRID", StringComparison.OrdinalIgnoreCase) ||
                     string.Equals(campusCode, "PARIS", StringComparison.OrdinalIgnoreCase))
                    && isFAFundSource)
                {                    
                        return "KIPSIUUSA";
                }

                else if (!string.IsNullOrEmpty(campusCode) &&
                    (string.Equals(campusCode, "HD", StringComparison.OrdinalIgnoreCase) ||
                     string.Equals(campusCode, "MADRID", StringComparison.OrdinalIgnoreCase) ||
                     string.Equals(campusCode, "PARIS", StringComparison.OrdinalIgnoreCase))
                    && string.IsNullOrEmpty(fundSource) && string.Equals(billingTransactionCode, "CURTRAN", StringComparison.OrdinalIgnoreCase))
                {
                    return "KIPSIUUSA";
                }


                return fundSource;
            }
            else
            {
                return billingTransactionCode ?? "UNKNOWN";
            }
        }



        public string? GetProductCode(string? billingTransactionCode, string? programVersionCode, string? transactionType, string? fundSource, string? campusCode)
        {
            if (string.Equals(billingTransactionCode, "TUIT", StringComparison.OrdinalIgnoreCase))
            {
                return programVersionCode ?? "APPLICANT";
            }
            else if (string.Equals(transactionType, "P", StringComparison.OrdinalIgnoreCase))
            {
                if (!string.IsNullOrEmpty(campusCode) &&
                    (string.Equals(campusCode, "FLORIDA", StringComparison.OrdinalIgnoreCase) ||
                     string.Equals(campusCode, "DL", StringComparison.OrdinalIgnoreCase) ||
                     string.Equals(campusCode, "HQ", StringComparison.OrdinalIgnoreCase))
                    && !string.IsNullOrEmpty(fundSource))
                {
                    string upperFundSource = fundSource.ToUpperInvariant();

                    if (upperFundSource == "PELL" || upperFundSource == "2324 PEL" || upperFundSource == "DLGPL" ||
                        upperFundSource == "DIRPLUS" || upperFundSource == "DIRSUB" ||
                        upperFundSource == "DIRUNSUB" || upperFundSource == "PRIVATEL" ||
                        upperFundSource == "SEOG" || upperFundSource == "SEOGMAT" ||
                        upperFundSource == "C33VB" || upperFundSource == "VAVOCREH")
                    {
                        return $"{upperFundSource}-USA";
                    }
                }


                else if (!string.IsNullOrEmpty(campusCode) &&
                    (string.Equals(campusCode, "HD", StringComparison.OrdinalIgnoreCase) ||
                     string.Equals(campusCode, "MADRID", StringComparison.OrdinalIgnoreCase) ||
                     string.Equals(campusCode, "PARIS", StringComparison.OrdinalIgnoreCase))
                    && string.Equals(fundSource, "SEOGMAT", StringComparison.OrdinalIgnoreCase))
                {
                    return "SEOGMAT";
                }


                else if (!string.IsNullOrEmpty(campusCode) &&
                    (string.Equals(campusCode, "HD", StringComparison.OrdinalIgnoreCase) ||
                     string.Equals(campusCode, "MADRID", StringComparison.OrdinalIgnoreCase) ||
                     string.Equals(campusCode, "PARIS", StringComparison.OrdinalIgnoreCase))
                    && !string.IsNullOrEmpty(fundSource))
                {
                    string upperFundSource = fundSource.ToUpperInvariant();
                    return upperFundSource;

                }

                else if (!string.IsNullOrEmpty(campusCode) &&
                    (string.Equals(campusCode, "HD", StringComparison.OrdinalIgnoreCase) ||
                     string.Equals(campusCode, "MADRID", StringComparison.OrdinalIgnoreCase) ||
                     string.Equals(campusCode, "PARIS", StringComparison.OrdinalIgnoreCase))
                    && string.IsNullOrEmpty(fundSource) && string.Equals(billingTransactionCode, "CURTRAN", StringComparison.OrdinalIgnoreCase))
                {
                    return "KIPSIUUSA";
                }


                return fundSource;
            }
            else
            {
                return billingTransactionCode ?? "UNKNOWN";
            }
        }


        /// <summary>
        /// This method is used for find academic year in "YYYY-YY" format.
        /// </summary>
        /// <param name="academicYears, academicYearSequence"></param>
        /// <returns>string</returns>
        private string GetAcademicYear(List<AcademicYears> academicYears, int? academicYearSequence, string? fundSource, string? campusCode, string? billingTransactionCode)
        {
            try
            {
                var FAFundSource = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
                {
                 "PELL", "2324 PEL", "DLGPL", "DIRPLUS", "DIRSUB",
                 "DIRUNSUB", "PRIVATEL", "SEOG", "C33VB", "VAVOCREH"
                };

                bool isFAFundSource = !string.IsNullOrEmpty(fundSource) && FAFundSource.Contains(fundSource);

                if (isFAFundSource &&
                 !string.Equals(fundSource, "SEOGMAT", StringComparison.OrdinalIgnoreCase) &&
                 (string.Equals(campusCode, "HD", StringComparison.OrdinalIgnoreCase) ||
                  string.Equals(campusCode, "MADRID", StringComparison.OrdinalIgnoreCase) ||
                  string.Equals(campusCode, "PARIS", StringComparison.OrdinalIgnoreCase)))
                {
                    return "US1";
                }

                if (string.IsNullOrEmpty(fundSource) && (string.Equals(campusCode, "HD", StringComparison.OrdinalIgnoreCase) ||
                     string.Equals(campusCode, "MADRID", StringComparison.OrdinalIgnoreCase) ||
                     string.Equals(campusCode, "PARIS", StringComparison.OrdinalIgnoreCase)) 
                     && (string.Equals(billingTransactionCode, "CURTRAN", StringComparison.OrdinalIgnoreCase)))
                {
                    return "US1";
                }


                if (academicYears.Count == 0 || academicYearSequence == null || academicYearSequence <= 0)
                {
                    return "APP";
                }               
                var selectedYear = academicYears?.FirstOrDefault(ay => ay.Sequence == academicYearSequence)?.FirstAwardYear;

                if (selectedYear != null && fundSource is null)  // != "SEOGMAT"
                {
                    return selectedYear;
                }                
                return string.Empty;
            }
            catch (Exception)
            {
                throw;
            }            
        }

        /// <summary>
        /// Convert the transactionAmount -ve or +ve on the basis of transactionType.
        /// </summary>
        /// <param name="transactionAmount"></param>
        /// <param name="transactionType"></param>
        /// <returns></returns>
        public string GetConvertedAmount(decimal transactionAmount, string? transactionType)
        {
            try
            {
                decimal amount = transactionAmount * 100;

                if (string.Equals(transactionType, "C", StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(transactionType, "P", StringComparison.OrdinalIgnoreCase))
                {
                    amount = -amount; 
                }

                return amount.ToString("F0"); // Format without decimals
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        /// <summary>
        /// This method will fetch all Unmatch Customer Transactions.
        /// </summary>
        /// <returns>It will return CustomerTransaction type</returns>
        /// <exception cref="HttpRequestException"></exception>
        public async Task<List<CustomerTransaction>> GetUnmatchCustomerTransactionsAsync()
        {
            BlobServiceClient blobServiceClient = new BlobServiceClient(_configuration["Storage:StorageAccountConnectionString"]);
            BlobContainerClient logFileContainer = blobServiceClient.GetBlobContainerClient(_configuration["Log:LogFileContainer"]);
            try
            {

                SharedHttpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", _u4authToken);

                var requestUrl = $"{_configuration["Unit4Api:BaseUrl3"]}/objects/customer-transactions?unmatchedCustomerInvoices=true&matchedCustomerInvoices=false&companyId=US1";
                var response = await SharedHttpClient.GetAsync(requestUrl);
                if (response.IsSuccessStatusCode)
                {
                    // Parse and return the response
                    var customerTransactions = await response.Content.ReadFromJsonAsync<List<CustomerTransaction>>();
                    return customerTransactions ?? new List<CustomerTransaction>();
                }
                else if (response.StatusCode == HttpStatusCode.NotFound)
                {
                   // _logger.LogWarning($"No unmatched customer transactions found at the specified endpoint: {requestUrl}");
                    return new List<CustomerTransaction>();
                }
                else if (response.StatusCode == HttpStatusCode.Unauthorized)
                {
                    throw new HttpRequestException("Unauthorized access - check your API credentials.");
                }
                else
                {
                    var responseBody = await response.Content.ReadAsStringAsync();
                    throw new HttpRequestException($"Invalid response status code: {response.StatusCode}. Response body: {responseBody}");
                }
            }
            catch (Exception ex)
            {
                // _logger.LogError($"Error while fetching unmatched customer transactions: {ex.Message}");
                LogErrorToBlob(logFileContainer, ex);
                return new List<CustomerTransaction>();
            }
        }


        /// <summary>
        /// This method use for fetching Invoice number from U4 system.
        /// </summary>
        /// <param name="customerId"></param>
        /// <param name="unmatchedTransactions"></param>
        /// <param name="acadmicYear"></param>
        /// <param name="transactionType"></param>
        /// <returns>string value of InvoiceNumber</returns>
        public string GetInvoiceNumber(string customerId, List<CustomerTransaction>? unmatchedTransactions, string acadmicYear, string? transactionType)
        {
            try
            {                
                    var unmatchedTransactionsForCustomer = unmatchedTransactions.Where(x => x.Invoice.CustomerId == customerId).ToList();
                    var unmatchedTxForCustomerByType = unmatchedTransactionsForCustomer.Where(x => x.TransactionType == "TI").ToList();
                    var unmatchedTxForCustomerByTypeAndYear = unmatchedTxForCustomerByType.Where(x => x.AccountingInformation?.Column2?.DimValue == acadmicYear).ToList();

                    if (unmatchedTxForCustomerByTypeAndYear.Count == 1)
                    {
                        string invoiceNumber = unmatchedTxForCustomerByTypeAndYear[0].Invoice.InvoiceNumber;
                        return invoiceNumber ?? string.Empty;
                    }
               
                return string.Empty;
            }
            catch (Exception)
            {
                throw;
            }            
        }

        public string GetVoucherType(string? accountReceivableBalance, string? billingTransactionCode, string? type, string? source, string? latamStudent)
        {
            billingTransactionCode = billingTransactionCode?.ToUpper().Trim();
            type = type?.ToUpper().Trim();

            if (!string.IsNullOrWhiteSpace(latamStudent) && latamStudent.Trim().Equals("Yes", StringComparison.OrdinalIgnoreCase))
            {
                return "20"; // invoice not send
            }

            if (type == "C" && source == "S")
            {
                return "20";  
            }

            if (billingTransactionCode == "TUIT" || billingTransactionCode == "ACF" || type == "P")
            {
                decimal balance = 0;

                if (!string.IsNullOrEmpty(accountReceivableBalance))
                {
                    decimal.TryParse(accountReceivableBalance, out balance);
                }

                if (balance <= 0)
                {
                    return "20"; // invoice not send
                }
                else
                {
                    return "19"; // invoice send
                }
            }

            if (billingTransactionCode == "REGALDP" || billingTransactionCode == "OTHF" ||
                billingTransactionCode == "THESIS" || billingTransactionCode == "UOR" ||
                billingTransactionCode == "CLEANING" || billingTransactionCode == "GRAD" ||
                billingTransactionCode == "PARKING" || billingTransactionCode == "ROOM" ||
                billingTransactionCode == "RESIT" || billingTransactionCode == "WDL" || 
                billingTransactionCode == "TUITDEP" || billingTransactionCode == "UORWDL")
            {
                return "19";
            }

            if (billingTransactionCode == "WRITEOFF" || billingTransactionCode == "CURTRAN")
            {
                return "20";
            }
            return "20";
        }


        /// <summary>
        /// Fetch the Charges data from Anthology ERP.
        /// </summary>
        /// <param name="null">Not providing any parameter but during execution it will call Anthology GET API which is provided by Anthology</param>
        /// <returns>It will return the List of all payment data as per its criteria in Lg04Row format .</returns>
        /// <exception >Exception may occur during mapping of field values of 'paymentData' into  Lg04Row object </exception>        
        public async Task<List<Lg04Row>> FetchChargesFromAnthology(DateTime? lastRunTime)
        {
            BlobServiceClient blobServiceClient = new BlobServiceClient(_configuration["Storage:StorageAccountConnectionString"]);
            BlobContainerClient createFileContainer = blobServiceClient.GetBlobContainerClient(_configuration["File:CreateFileContainer"]);
            BlobContainerClient logFileContainer = blobServiceClient.GetBlobContainerClient(_configuration["Log:LogFileContainer"]);

            try
            {
                string currentDate =  DateTime.UtcNow.ToString("yyyy-MM-ddT00:00:00Z");  //  "2027-06-01T00:00:00Z"; //
                //string chargeApi = $@"https://sisclientweb-test-101053.campusnexus.cloud/ds/campusnexus/StudentAccountTransactions?$filter=(Type eq 'I' or Type eq 'C' or Type eq 'D' or Type eq 'P') and (CreatedDateTime gt 2025-01-10T00:00:00Z) and (Student/StudentNumber eq '00096172')&$select=StudentId,ReceiptNumber,AcademicYearSequence,Type,Source,PaymentType,AmountPaid,Reference,CheckNumber,Id,PostDate,TransactionNumber,TransactionAmount,BillingTransactionCode,Status,Description,TransactionDate,LastModifiedDateTime,CreatedDateTime,ReceiptPrintedDate&$expand=Term($select=Id,Name),Campus($select=Id,Name,Code),Student($select=Id,StudentNumber,ArBalance;$expand=AgencyBranches($select=Id;$expand=AgencyBranch($select=Id,Name;$expand=Agency($select=Id,Code,Name)))),StudentEnrollmentPeriod($select=Id,EnrollmentNumber,AccountReceivableBalance;$expand=ProgramVersion($select=Id,Code,Name;$expand=Degree($select=Id,Name)),GradeScale($select=Id,Code,Name),AcademicYears($select=Id,AcademicYearId,Sequence,StartDate,EndDate,FirstAwardYear)),BankAccount($select=AccountName,Currency,AccountNumber,GlCreditAccount,GlDebitAccount),ExtendedProperties($select=Name,StringValue),,StudentAward($select=Id;$expand=FundSource($select=Code,Name))";
                string chargeApi = _configuration["AnthologyConfig:Charges"].Replace("{currentDate}", currentDate, StringComparison.OrdinalIgnoreCase);
                var authToken = Convert.ToBase64String(Encoding.UTF8.GetBytes($"{_creden.AnthologyUsername}:{_creden.AnthologyPassword}"));
                SharedHttpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", authToken);
                //y var chargesResponse = await SharedHttpClient.GetStringAsync(chargeApi);
                var chargesResponse = await SharedHttpClient.GetStringAsync(_configuration["AnthologyConfig:Charges"]);
                var chargeData = JsonConvert.DeserializeObject<ChargesApiResponse>(chargesResponse);
                                
                string chargeApiFA = _configuration["AnthologyConfig:ChargesFA"].Replace("{currentDate}", currentDate, StringComparison.OrdinalIgnoreCase);
                //y var chargesResponseFA = await SharedHttpClient.GetStringAsync(chargeApiFA);
                var chargesResponseFA = await SharedHttpClient.GetStringAsync(_configuration["AnthologyConfig:ChargesFA"]);
                var chargeDataFA = JsonConvert.DeserializeObject<ChargesApiResponse>(chargesResponseFA);

                //Logic for combine two API response into one
                var chargeDataFADict = chargeDataFA.Value.ToDictionary(
                    cfa => new
                    {
                        cfa.Student.StudentNumber,
                        cfa.TransactionNumber,
                        cfa.TransactionAmount,
                        cfa.TransactionDate,
                        cfa.Source,
                        cfa.Type
                    },
                    cfa => cfa
                );

                // Prepare the final combined response
                var chargeDataFinal = new ChargesApiResponse
                {
                    Value = new List<Charges>()
                };

                foreach (var charge in chargeData.Value)
                {
                    // Create the key for lookup in chargeDataFA dictionary
                    var key = new
                    {
                        charge.Student.StudentNumber,
                        charge.TransactionNumber,
                        charge.TransactionAmount,
                        charge.TransactionDate,
                        charge.Source,
                        charge.Type
                    };

                    if (chargeDataFADict.TryGetValue(key, out var matchedChargeFA))
                    {
                        // If match found, copy StudentAward from matched record
                        charge.StudentAward = matchedChargeFA.StudentAward;
                    }

                    chargeDataFinal.Value.Add(charge);
                }
                //Logic for combine two API end

              //yy  chargeDataFinal.Value = chargeDataFinal.Value.Where(y => y.CreatedDateTime > lastRunTime).ToList();

                chargeDataFinal.Value = chargeDataFinal.Value.Where(x =>
                      (
                          x.Type == "I" ||
                          x.Type == "C" ||
                          x.Type == "D" ||
                          (x.Type == "P" && x.Source == "F") ||
                          (x.Type == "P" && x.StudentAward?.FundSource?.Code == "2324 PEL") ||
                          (x.Type == "P" && x.StudentAward?.FundSource?.Code == "DLGPL") ||
                          (x.Type == "P" && x.StudentAward?.FundSource?.Code == "DIRPLUS") ||
                          (x.Type == "P" && x.StudentAward?.FundSource?.Code == "DIRSUB") ||
                          (x.Type == "P" && x.StudentAward?.FundSource?.Code == "DIRUNSUB") ||
                          (x.Type == "P" && x.StudentAward?.FundSource?.Code == "PELL") ||
                          (x.Type == "P" && x.StudentAward?.FundSource?.Code == "PRIVATEL") ||
                          (x.Type == "P" && x.StudentAward?.FundSource?.Code == "SEOG") ||
                          (x.Type == "P" && x.StudentAward?.FundSource?.Code == "SEOGMAT") ||
                          (x.Type == "P" && x.StudentAward?.FundSource?.Code == "C33VB") ||
                          (x.Type == "P" && x.StudentAward?.FundSource?.Code == "VAVOCREH")
                      )
                       
                      && !(x.Type == "I" && x.BillingTransactionCode == "APPFEE")
                  )
                  .ToList();

                //chargeDataFinal.Value = chargeDataFinal.Value.Where(x =>
                //    x.Type == "I" ||
                //    x.Type == "C" ||
                //    x.Type == "D" ||
                //    (x.Type == "P" && x.Source == "F") ||
                //    (x.Type == "P" && x.StudentAward?.FundSource?.Code == "2324 PEL") ||
                //    (x.Type == "P" && x.StudentAward?.FundSource?.Code == "DLGPL") ||
                //    (x.Type == "P" && x.StudentAward?.FundSource?.Code == "DIRPLUS") ||
                //    (x.Type == "P" && x.StudentAward?.FundSource?.Code == "DIRSUB") ||
                //    (x.Type == "P" && x.StudentAward?.FundSource?.Code == "DIRUNSUB") ||
                //    (x.Type == "P" && x.StudentAward?.FundSource?.Code == "PELL") ||
                //    (x.Type == "P" && x.StudentAward?.FundSource?.Code == "PRIVATEL") ||
                //    (x.Type == "P" && x.StudentAward?.FundSource?.Code == "SEOGL") ||
                //    (x.Type == "P" && x.StudentAward?.FundSource?.Code == "SEOGMAT") ||
                //    (x.Type == "P" && x.StudentAward?.FundSource?.Code == "C33VB") ||
                //    (x.Type == "P" && x.StudentAward?.FundSource?.Code == "VAVOCREH")

                //// Here i want to add one more filter such that-> it Remove transaction where (x.Type == "I" && x.BillingTransactionCode == "APPFEE")

                //).ToList();

                var chargeDataGroupedByStudentId = chargeDataFinal?.Value?.GroupBy(x => x.Student.StudentNumber);

                if (chargeDataGroupedByStudentId is not null && chargeDataGroupedByStudentId.Any())
                {
                   // var unmatchedTransactions = await GetUnmatchCustomerTransactionsAsync();
                    string totalCount = chargeDataFinal.Value.Count().ToString();
                    await LogSuccessToBlob(null, logFileContainer, totalCount);
                    List<Lg04Row> lg04Output = new List<Lg04Row>();
                    List<Lg04Row> lg04ForLog = new List<Lg04Row>();
                    long orderId = 0;
                    string baseString = _lg04Values.BaseBatchId;
                    string generatedBatchId = GenerateUniqueBatch(baseString);
                    
                    try
                    {
                        foreach (var grouping in chargeDataGroupedByStudentId)
                        {
                            var student = grouping.Key;
                            int linvalue = _lg04Values.LineNoHeader;
                            var legentityH = GetLEGENTITY(grouping.FirstOrDefault()?.Campus.Name, null);
                            var costCenterH = GetExtendedProperties(grouping.FirstOrDefault()?.ExtendedProperties.FirstOrDefault()?.StringValue, grouping.FirstOrDefault()?.Campus?.Code, null);                            
                            var currencyCode = GetCurrencyCode(grouping.FirstOrDefault()?.Campus?.Name);
                            var academicYearH = GetAcademicYear(grouping.FirstOrDefault()?.StudentEnrollmentPeriod.AcademicYears, grouping.FirstOrDefault()?.AcademicYearSequence, null, null, null);
                           // var invoiceNumber = GetInvoiceNumber(student, unmatchedTransactions, academicYearH, grouping.FirstOrDefault()?.Type);
                            var voucherType = GetVoucherType(grouping.FirstOrDefault()?.StudentEnrollmentPeriod.AccountReceivableBalance.ToString(), grouping.FirstOrDefault()?.BillingTransactionCode, grouping.FirstOrDefault()?.Type, grouping.FirstOrDefault()?.Source, grouping.FirstOrDefault()?.StudentEnrollmentPeriod?.ExtendedProperties.FirstOrDefault()?.StringValue);
                            string agency = GetAgency(grouping.FirstOrDefault()?.Student.AgencyBranches.FirstOrDefault()?.AgencyBranch?.Agency?.Code, student);

                            orderId++;
                            var lg04RowHeader = new Lg04Row
                            {
                                OrderId = orderId,
                                BatchId = generatedBatchId,
                                Client = _lg04Values.Client,
                                VoucherType = voucherType, 
                                AparId = student,
                                LineNo = linvalue,
                                MainAparId = agency, 
                                OrderDate = grouping.FirstOrDefault()?.TransactionDate.ToString("yyyyMMdd"), 
                                Responsible = _lg04Values.Responsible1,
                                Responsible2 = _lg04Values.Responsible2,
                                SequenceNo = _lg04Values.SequenceNo,
                                TransType = _lg04Values.TransType,
                                Att1Id = _lg04Values.Att1Id,
                                Att2Id = _lg04Values.Att2Id,
                               // Att3Id = _lg04Values.Att3Id,
                                Att4Id = _lg04Values.Att4Id,
                                Att5Id = _lg04Values.Att5Id,
                                Att6Id = _lg04Values.Att6Id,
                                Att7Id = _lg04Values.Att7Id,
                                DimValue1 = costCenterH,  
                                DimValue2 = academicYearH, 
                                DimValue5 = grouping.FirstOrDefault()?.Campus.Code, //LEVELOFSTUDY
                                DimValue6 = student, 
                                DimValue7 = legentityH, 
                                Currency = currencyCode,

                                ExtOrdRef = grouping.FirstOrDefault()?.Reference is { } r ? r[..Math.Min(9, r.Length)] : null, // grouping.FirstOrDefault()?.Reference ,
                                //Text1 = invoiceNumber 

                            };
                            lg04Output.Add(lg04RowHeader);

                            foreach (var charge in grouping)
                            {
                                try
                                {
                                    linvalue++;
                                    //orderId++;                                    
                                    string convertedAmount = GetConvertedAmount(charge.TransactionAmount, charge.Type); //  (charge.TransactionAmount * 100).ToString("F0");
                                    var gradeScaled = GetGradeScale(charge.StudentEnrollmentPeriod.GradeScale.Name, charge.StudentAward?.FundSource?.Code, charge.Type);
                                    var legentityL = GetLEGENTITY(charge.Campus.Name, charge.StudentAward?.FundSource?.Code);                                    
                                    var costCenterL = GetExtendedProperties(charge.ExtendedProperties.FirstOrDefault()?.StringValue, charge.Campus?.Code, charge.StudentAward?.FundSource?.Code); 
                                    var academicYearL = GetAcademicYear(charge.StudentEnrollmentPeriod.AcademicYears, charge.AcademicYearSequence, charge.StudentAward?.FundSource?.Code, charge.Campus?.Code, charge.BillingTransactionCode);
                                    string productCode = GetProductCode(charge.BillingTransactionCode, charge.StudentEnrollmentPeriod?.ProgramVersion?.Code, charge.Type, charge.StudentAward?.FundSource?.Code, charge.Campus?.Code);  //charge.StudentEnrollmentPeriod?.ProgramVersion?.Code ?? "DEPOSIT";
                                    string dim3 = GetProductCodeD3(charge.BillingTransactionCode, charge.StudentEnrollmentPeriod?.ProgramVersion?.Code, charge.Type, charge.StudentAward?.FundSource?.Code, charge.Campus?.Code);
                                    string campusCode = GetcampusCode(charge.Campus?.Code, charge.StudentAward?.FundSource?.Code, charge.BillingTransactionCode);

                                    var lg04RowLine = new Lg04Row
                                    {
                                        BatchId = generatedBatchId,
                                        Client = _lg04Values.Client,
                                        OrderId = orderId,
                                        CurAmount = decimal.Parse(convertedAmount),
                                        Amount = decimal.Parse(convertedAmount),
                                        Article = productCode, 
                                        LineNo = linvalue,
                                        Dim1 = costCenterL, 
                                        Dim2 = academicYearL, 
                                        Dim3 = dim3, 
                                        Dim5 = campusCode,
                                        Dim6 = gradeScaled, 
                                        Dim7 = legentityL,
                                        TransType = _lg04Values.TransType,
                                        AmountSet = _lg04Values.AmountSet,
                                        Value1 = 100
                                        
                                    };                                   
                                    lg04Output.Add(lg04RowLine);
                                    lg04ForLog.Add(lg04RowHeader);
                                }
                                catch (Exception ex)
                                {
                                    await LogChargeErrorToBlob(charge.Student?.StudentNumber, charge.Campus?.Code, charge.TransactionAmount, logFileContainer, ex);
                                    Console.WriteLine($"Error occurred in processing charges with Id: {charge.Student?.StudentNumber}. Exception: {ex.Message}");
                                }
                            }
                        }

                        LogSuccessToBlob(lg04ForLog, logFileContainer, lg04ForLog.Count.ToString());
                        var fixedLengthItems = new FixedWidthLinesProvider<Lg04Row>().Write(lg04Output);
                        // Convert lg04Output to CSV format
                        var csvData = new StringBuilder();
                        using (var writer = new StringWriter(csvData))
                        using (var csv = new CsvWriter(writer, CultureInfo.InvariantCulture))
                        {
                            csv.WriteHeader<Lg04Row>();
                            csv.NextRecord();
                            csv.WriteRecords(lg04Output);
                        }
                        string txtBlobName = $"{generatedBatchId}.txt";
                        string csvBlobName = $"{generatedBatchId}.csv";

                        BlobClient txtBlobClient = createFileContainer.GetBlobClient(txtBlobName);
                        using (var stream = new MemoryStream(Encoding.UTF8.GetBytes(string.Join("\n", fixedLengthItems))))
                        {
                            await txtBlobClient.UploadAsync(stream, true);
                        }
                        // Upload the CSV file content to Blob
                        BlobClient csvBlobClient = createFileContainer.GetBlobClient(csvBlobName);
                        using (var stream = new MemoryStream(Encoding.UTF8.GetBytes(csvData.ToString())))
                        {
                            await csvBlobClient.UploadAsync(stream, true);
                        }
                        string txtFileBlobUri = txtBlobClient.Uri.ToString();
                        string csvFileBlobUri = csvBlobClient.Uri.ToString();
                        Console.WriteLine($"Text file for charge saved at {txtFileBlobUri}");
                        Console.WriteLine($"CSV file for charge saved at {csvFileBlobUri}");

                        _sftpClient.UploadFile(txtFileBlobUri, txtBlobName);
                        string sftpMessage = $"SFTP successfully transfer text file {txtBlobName}";
                        await LogSftpToBlob(logFileContainer, sftpMessage);
                        Console.WriteLine(sftpMessage);                       

                    }
                    catch (Exception ex)
                    {
                        // LogErrorToBlob(logFileContainer, ex);
                        Console.WriteLine($"An error occurred while processing charges: {ex.Message}");
                    }
                }
                else
                {
                    Exception ex = new Exception($"No data found in 'Charges' API response for provided Date and time {DateTime.UtcNow}");
                    LogErrorToBlob(logFileContainer, ex);
                    Console.WriteLine($"No data found in charges API response for provided Date and time {DateTime.UtcNow}");
                }

                return new List<Lg04Row>(); // Return empty list if no data

            }
            catch (Exception ex)
            {
                await LogErrorToBlob(logFileContainer, ex);
                throw ex;
            }

        }


        /// <summary>
        /// This Method is used for generating Unique BatchId.
        /// </summary>
        /// <param name="baseString"> Providing baseString as parameter  during execution</param>
        /// <returns>It will return the unique BatchId for each iteration.</returns>
        public string GenerateUniqueBatch(string baseString)
        {
            DateTime now = DateTime.Now;
            string dateTimePart = $"{now:yyyyMMdd_HHmm}"; 
            return $"{baseString}_{dateTimePart}";
        }


        /// <summary>
        /// This function is used for converting decimal value to its negative value.
        /// </summary>
        /// <param name="value">We need to provide value which want to convert in its negative value</param>
        /// <returns> Its return type is decimal, returning negative value</returns>
        decimal GetNegativeValue(decimal value)
        {
            return -value;
        }

        
        /// <summary>
        /// This function is used for logging successful iterations to Blob.
        /// </summary>
        /// <param name="string Id, string logFilePath, Exception ex">We need to provide 3 parameter to this method</param>
        /// <returns> Its return type is void, not returning any value.</returns>
        /// <exception >    </exception>        
        private async Task LogSuccessToBlob(List<Lg04Row>? lg04Output, BlobContainerClient logFileContainer, string? totalCount)
        {
            try
            {
                string logFileName = $"{DateTime.Now:yyyyMMdd}_ChargeSuccess.log";
                BlobClient logBlobClient = logFileContainer.GetBlobClient(logFileName);
                StringBuilder logContent = new StringBuilder();
                if (await logBlobClient.ExistsAsync())
                {
                    var downloadResult = await logBlobClient.DownloadContentAsync();
                    logContent.Append(downloadResult.Value.Content.ToString());
                }
                logContent.AppendLine(totalCount);
                if (lg04Output != null && lg04Output.Any())
                {
                    foreach (var student in lg04Output)
                    {
                        var logMessage = $"Success: Processed charge record for: {student.AparId}, Charge details: {JsonConvert.SerializeObject(new { student.AparId, student.OrderDate })}{Environment.NewLine}";                        
                        logContent.AppendLine(logMessage);
                    }
                    Console.WriteLine($"Success logging Done");
                }
                using (var stream = new MemoryStream(Encoding.UTF8.GetBytes(logContent.ToString())))
                {
                    await logBlobClient.UploadAsync(stream, overwrite: true);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error logging charge for Student. Exception: {ex.Message}");
            }
        }


        /// <summary>
        /// This function is used for logging error which may occur during execution of application.
        /// </summary>
        /// <param name="string Id, string logFilePath, Exception ex">We need to provide 3 parameter to this method</param>
        /// <returns> Its return type is void, not returning any value.</returns>
        /// <exception > This method itself used for logging error/exception so its not going to use for logging its own exception</exception>
        private async Task LogErrorToBlob(string Id, BlobContainerClient logFileContainer, Exception ex)
        {
            try
            {                
                var logMessage = $"Error: Id: {Id}, Exception: {ex.Message}, StackTrace: {ex.StackTrace}{Environment.NewLine}";
                string logFileName = $"{DateTime.Now:yyyyMMdd}_error.log";
                // Get a reference to the daily log file in Blob
                BlobClient logBlobClient = logFileContainer.GetBlobClient(logFileName);
                string existingLog = "";
                if (await logBlobClient.ExistsAsync())
                {
                    var downloadResult = await logBlobClient.DownloadContentAsync();
                    existingLog = downloadResult.Value.Content.ToString();
                }
                string updatedLog = existingLog + logMessage;
                using (var stream = new MemoryStream(Encoding.UTF8.GetBytes(updatedLog)))
                {
                    await logBlobClient.UploadAsync(stream, overwrite: true);
                }
            }
            catch (Exception logEx)
            {
                Console.WriteLine($"Error logging error for Id: {Id}. Exception: {logEx.Message}");
            }
        }

        private async Task LogChargeErrorToBlob(string Id, string? campusCode, decimal? amount, BlobContainerClient logFileContainer, Exception ex)
        {
            try
            {
                var logMessage = $"Error occurred during charge processing for studentId: {Id}, CampusCode: {campusCode}, Amount: {amount}, Exception: {ex.Message}, StackTrace: {ex.StackTrace}{Environment.NewLine}";
                string logFileName = $"{DateTime.Now:yyyyMMdd}_ChargeEerror.log";
                // Get a reference to the daily log file in Blob
                BlobClient logBlobClient = logFileContainer.GetBlobClient(logFileName);
                string existingLog = "";
                if (await logBlobClient.ExistsAsync())
                {
                    var downloadResult = await logBlobClient.DownloadContentAsync();
                    existingLog = downloadResult.Value.Content.ToString();
                }
                string updatedLog = existingLog + logMessage;
                using (var stream = new MemoryStream(Encoding.UTF8.GetBytes(updatedLog)))
                {
                    await logBlobClient.UploadAsync(stream, overwrite: true);
                }
            }
            catch (Exception logEx)
            {
                Console.WriteLine($"Error logging error for Id: {Id}. Exception: {logEx.Message}");
            }
        }

        public async Task LogErrorToBlob(BlobContainerClient logFileContainer, Exception ? ex)
        {
            try
            {
                var logMessage = $"Exception: {ex.Message}, StackTrace: {ex.StackTrace}{Environment.NewLine}";
                string logFileName = $"{DateTime.Now:yyyyMMdd}_error.log";
                
                BlobClient logBlobClient = logFileContainer.GetBlobClient(logFileName);
                string existingLog = "";
                if (await logBlobClient.ExistsAsync())
                {
                    var downloadResult = await logBlobClient.DownloadContentAsync();
                    existingLog = downloadResult.Value.Content.ToString();
                }
                string updatedLog = existingLog + logMessage;
                using (var stream = new MemoryStream(Encoding.UTF8.GetBytes(updatedLog)))
                {
                    await logBlobClient.UploadAsync(stream, overwrite: true);
                }
            }
            catch (Exception logEx)
            {
                Console.WriteLine($"Error logging error for processing data. Exception: {logEx.Message}");
            }
        }

        public async Task LogSftpToBlob(BlobContainerClient logFileContainer, string message)
        {
            try
            {
                var logMessage = message + Environment.NewLine; //$"Exception: {ex.Message}, StackTrace: {ex.StackTrace}{Environment.NewLine}";
                string logFileName = $"{DateTime.Now:yyyyMMdd}_SftpTransfer.log";

                BlobClient logBlobClient = logFileContainer.GetBlobClient(logFileName);
                string existingLog = "";
                if (await logBlobClient.ExistsAsync())
                {
                    var downloadResult = await logBlobClient.DownloadContentAsync();
                    existingLog = downloadResult.Value.Content.ToString();
                }
                string updatedLog = existingLog + logMessage;
                using (var stream = new MemoryStream(Encoding.UTF8.GetBytes(updatedLog)))
                {
                    await logBlobClient.UploadAsync(stream, overwrite: true);
                }
            }
            catch (Exception logEx)
            {
                Console.WriteLine($"Error occur in logging sftp transfer log. Exception: {logEx.Message}");
            }
        }

        public async Task StudentErrorLog(BlobContainerClient logFileContainer, Exception? ex)
        {
            try
            {
                string logFileName = $"{DateTime.Now:yyyyMMdd}_studentError.log";
                string logMessage = $"Exception: {ex?.Message}, StackTrace: {ex?.StackTrace}{Environment.NewLine}";

                // Get a reference to the Append Blob
                AppendBlobClient appendBlobClient = logFileContainer.GetAppendBlobClient(logFileName);

                // Create the blob if it doesn't exist
                if (!await appendBlobClient.ExistsAsync())
                {
                    await appendBlobClient.CreateAsync();
                }

                using (var stream = new MemoryStream(Encoding.UTF8.GetBytes(logMessage)))
                {
                    await appendBlobClient.AppendBlockAsync(stream);
                }

            }
            catch (Exception logEx)
            {
                Console.WriteLine($"Error occurred in logging error for processing student/customer. Exception: {logEx.Message}");
            }
        }
    }
}
