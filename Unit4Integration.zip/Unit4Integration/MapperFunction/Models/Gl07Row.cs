﻿using MapperFunction.Infrastructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MapperFunction.Models
{
    public class Gl07Row : ICloneable
    {
        [FixedWidthLineField(Start = 1, Length = 25)]
        public string? BatchId { get; set; }

        [FixedWidthLineField(Start = 26, Length = 25)]
        public string? Interface { get; set; }

        [FixedWidthLineField(Start = 51, Length = 25)]
        public string? VoucherType { get; set; }

        [FixedWidthLineField(Start = 76, Length = 2)]
        public string? TransType { get; set; }

        [FixedWidthLineField(Start = 78, Length = 25)]
        public string? Client { get; set; }

        [FixedWidthLineField(Start = 103, Length = 25)]
        public string? Account { get; set; }

        [FixedWidthLineField(Start = 128, Length = 25)]
        public string? Dim1 { get; set; }

        [FixedWidthLineField(Start = 153, Length = 25)]
        public string? Dim2 { get; set; }

        [FixedWidthLineField(Start = 178, Length = 25)]
        public string? Dim3 { get; set; }

        [FixedWidthLineField(Start = 203, Length = 25)]
        public string? Dim4 { get; set; }

        [FixedWidthLineField(Start = 228, Length = 25)]
        public string? Dim5 { get; set; }

        [FixedWidthLineField(Start = 253, Length = 25)]
        public string? Dim6 { get; set; }

        [FixedWidthLineField(Start = 278, Length = 25)]
        public string? Dim7 { get; set; }

        [FixedWidthLineField(Start = 303, Length = 25)]
        public string? TaxCode { get; set; }

        [FixedWidthLineField(Start = 328, Length = 25)]
        public string? TaxSystem { get; set; }

        [FixedWidthLineField(Start = 353, Length = 25)]
        public string? Currency { get; set; }

        [FixedWidthLineField(Start = 378, Length = 2)]
        public int? DcFlag { get; set; }

        [FixedWidthLineField(Start = 380, Length = 20)]
        public decimal? CurAmount { get; set; }

        [FixedWidthLineField(Start = 400, Length = 20)]
        public decimal? Amount { get; set; }

        [FixedWidthLineField(Start = 420, Length = 11)]
        public int? Number1 { get; set; }

        [FixedWidthLineField(Start = 431, Length = 20)]
        public int? Value1 { get; set; }

        [FixedWidthLineField(Start = 451, Length = 20)]
        public int? Value2 { get; set; }

        [FixedWidthLineField(Start = 471, Length = 20)]
        public int? Value3 { get; set; }

        [FixedWidthLineField(Start = 491, Length = 255)]
        public string? Description { get; set; }

        [FixedWidthLineField(Start = 746, Length = 8)]
        public string? TransDate { get; set; }

        [FixedWidthLineField(Start = 754, Length = 8)]
        public string? VoucherDate { get; set; }

        [FixedWidthLineField(Start = 762, Length = 15)]
        public long? VoucherNo { get; set; }

        [FixedWidthLineField(Start = 777, Length = 6)]
        public long? Period { get; set; }

        [FixedWidthLineField(Start = 783, Length = 1)]
        public char? TaxId { get; set; }

        [FixedWidthLineField(Start = 784, Length = 100)]
        public string? ExtInvRef { get; set; }

        [FixedWidthLineField(Start = 884, Length = 255)]
        public string? ExtRef { get; set; }

        [FixedWidthLineField(Start = 1139, Length = 8)]
        public string? DueDate { get; set; }

        [FixedWidthLineField(Start = 1147, Length = 8)]
        public string? DiscDate { get; set; }

        [FixedWidthLineField(Start = 1155, Length = 20)]
        public decimal? Discount { get; set; }

        [FixedWidthLineField(Start = 1175, Length = 25)]
        public string? Commitment { get; set; }

        [FixedWidthLineField(Start = 1200, Length = 15)]
        public long? OrderId { get; set; }

        [FixedWidthLineField(Start = 1215, Length = 27)]
        public string? Kid { get; set; }

        [FixedWidthLineField(Start = 1242, Length = 2)]
        public string? PayTransfer { get; set; }

        [FixedWidthLineField(Start = 1244, Length = 1)]
        public char? Status { get; set; }

        [FixedWidthLineField(Start = 1245, Length = 1)]
        public char? AparType { get; set; }

        [FixedWidthLineField(Start = 1246, Length = 25)]
        public string? AparId { get; set; }

        [FixedWidthLineField(Start = 1271, Length = 1)]
        public char? PayFlag { get; set; }

        [FixedWidthLineField(Start = 1272, Length = 15)]
        public long? VoucherRef { get; set; }

        [FixedWidthLineField(Start = 1287, Length = 9)]
        public int? SequenceRef { get; set; }

        [FixedWidthLineField(Start = 1296, Length = 25)]
        public string? IntRuleId { get; set; }

        [FixedWidthLineField(Start = 1321, Length = 25)]
        public string? FactorShort { get; set; }

        [FixedWidthLineField(Start = 1346, Length = 25)]
        public string? Responsible { get; set; }

        [FixedWidthLineField(Start = 1371, Length = 255)]
        public string? AparName { get; set; }

        [FixedWidthLineField(Start = 1626, Length = 160)]
        public string? Address { get; set; }

        [FixedWidthLineField(Start = 1786, Length = 40)]
        public string? Province { get; set; }

        [FixedWidthLineField(Start = 1826, Length = 40)]
        public string? Place { get; set; }

        [FixedWidthLineField(Start = 1866, Length = 35)]
        public string? BankAccount { get; set; }

        [FixedWidthLineField(Start = 1901, Length = 2)]
        public string? PayMethod { get; set; }

        [FixedWidthLineField(Start = 1903, Length = 25)]
        public string? VatRegNo { get; set; }

        [FixedWidthLineField(Start = 1928, Length = 15)]
        public string? ZipCode { get; set; }

        [FixedWidthLineField(Start = 1943, Length = 3)]
        public string? CurrLicence { get; set; }

        [FixedWidthLineField(Start = 1946, Length = 25)]
        public string? Account2 { get; set; }

        [FixedWidthLineField(Start = 1971, Length = 20)]
        public decimal? BaseAmount { get; set; }

        [FixedWidthLineField(Start = 1991, Length = 20)]
        public decimal? BaseCurr { get; set; }

        [FixedWidthLineField(Start = 2011, Length = 4)]
        public string? PayTempId { get; set; }

        [FixedWidthLineField(Start = 2015, Length = 3)]
        public short? AllocationKey { get; set; }

        [FixedWidthLineField(Start = 2018, Length = 2)]
        public short? PeriodNo { get; set; }

        [FixedWidthLineField(Start = 2020, Length = 13)]
        public string? ClearingCode { get; set; }

        [FixedWidthLineField(Start = 2033, Length = 11)]
        public string? Swift { get; set; }

        [FixedWidthLineField(Start = 2044, Length = 15)]
        public long? ArriveId { get; set; }

        [FixedWidthLineField(Start = 2059, Length = 2)]
        public string? BankAccType { get; set; }

        [FixedWidthLineField(Start = 2061, Length = 25)]
        public string? PayCurrency { get; set; }

        [FixedWidthLineField(Start = 2086, Length = 8)]
        public string? ArrivalDate { get; set; }

        [FixedWidthLineField(Start = 2094, Length = 15)]
        public long? OrigReference { get; set; }

        [FixedWidthLineField(Start = 2109, Length = 25)]
        public string? Complaint { get; set; }

        [FixedWidthLineField(Start = 2134, Length = 8)]
        public string? ComplDelay { get; set; }

        public string? Intake { get; set; }

        public string? CountryCode { get; set; }

        public string? FlexiFieldValues { get; set; }

        public string? TransactionType { get; set; }

        public object Clone()
        {
            throw new NotImplementedException();
        }
    }

    public class FlexiFieldValues
    {
        public BillableTransInfo[]? BillableTransInfo { get; set; }
    }

    public class BillableTransInfo
    {
        public string? PartnerAward { get; set; }

        public decimal? PartnerFee { get; set; }
        public decimal? PartnersFee { get; set; }

        public decimal? OtherFee { get; set; }

        public bool? TransferredToUnit4 { get; set; }
    }
}
