﻿using Newtonsoft.Json;

namespace MapperFunction.Models.Unit4Api
{
    public class Invoice
    {
        [JsonProperty("calculatePayDiscountOnTax")]
        public bool? CalculatePayDiscountOnTax { get; set; }

        [JsonProperty("checkCreditOnHeadOffice")]
        public bool? CheckCreditOnHeadOffice { get; set; }

        [JsonProperty("creditLimit")]
        public int? CreditLimit { get; set; }

        [JsonProperty("currencyCode")]
        public string? CurrencyCode { get; set; }

        [JsonProperty("discountCode")]
        public string? DiscountCode { get; set; }

        [JsonProperty("hasFixedCurrency")]
        public bool? HasFixedCurrency { get; set; }

        [JsonProperty("hasFixedPaymentTerms")]
        public bool? HasFixedPaymentTerms { get; set; }

        [JsonProperty("hasFixedTaxSystem")]
        public bool? HasFixedTaxSystem { get; set; }

        [JsonProperty("headOffice")]
        public string? HeadOffice { get; set; }

        [JsonProperty("isSundryCustomer")]
        public bool? IsSundryCustomer { get; set; }

        [JsonProperty("languageCode")]
        public string? LanguageCode { get; set; }

        [JsonProperty("maxCreditDays")]
        public int? MaxCreditDays { get; set; }

        [JsonProperty("message")]
        public string? Message { get; set; }

        [JsonProperty("paymentPlanTemplateCode")]
        public string? PaymentPlanTemplateCode { get; set; }

        [JsonProperty("paymentTermsId")]
        public string? PaymentTermsId { get; set; }

        [JsonProperty("supplierId")]
        public string? SupplierId { get; set; }

        [JsonProperty("taxSystem")]
        public string? TaxSystem { get; set; }

        [JsonProperty("notificationMessages")]
        public NotificationMessages NotificationMessages { get; set; }
    }
}
