﻿using Newtonsoft.Json;

namespace MapperFunction.Models.Unit4Api
{
    public class ContactPoint
    {
        [JsonProperty("additionalContactInfo")]
        public AdditionalContactInfo AdditionalContactInfo { get; set; }

        [JsonProperty("address")]
        public Address? Address { get; set; }

        [JsonProperty("contactPointType")]
        public string? ContactPointType { get; set; }

        [JsonProperty("lastUpdated")]
        public LastUpdated? LastUpdated { get; set; }

        [JsonProperty("sortOrder")]
        public int? SortOrder { get; set; }

        [JsonProperty("notificationMessages")]
        public NotificationMessages? NotificationMessages { get; set; }

        [JsonProperty("phoneNumbers")]
        public PhoneNumbers? PhoneNumbers { get; set; }
    }
    public class PhoneNumbers
    {
        [JsonProperty("telephone1")]
        public string? Telephone1 { get; set; }

        [JsonProperty("telephone4")]
        public string? Telephone4 { get; set; }


        [JsonProperty("phoneNumber")]
        public string? PhoneNumber { get; set; }

        [JsonProperty("workPhoneNumber")]
        public string? WorkPhoneNumber { get; set; }

        [JsonProperty("otherPhoneNumber")]
        public string? OtherPhoneNumber { get; set; }
    }
}
