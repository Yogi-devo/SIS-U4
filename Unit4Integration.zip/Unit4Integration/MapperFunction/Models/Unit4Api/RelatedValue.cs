﻿using Newtonsoft.Json;

namespace MapperFunction.Models.Unit4Api
{
    public class RelatedValue
    {
        [JsonProperty("unitValue")]
        public int? UnitValue { get; set; }

        [JsonProperty("relationGroup")]
        public string? RelationGroup { get; set; }

        [JsonProperty("relationId")]
        public string? RelationId { get; set; }

        [JsonProperty("relationName")]
        public string? RelationName { get; set; }

        [JsonProperty("relatedValue")]
        public string? Value { get; set; }

        [JsonProperty("percentage")]
        public int? Percentage { get; set; }

        [JsonProperty("dateFrom")]
        public DateTime? DateFrom { get; set; }

        [JsonProperty("dateTo")]
        public DateTime? DateTo { get; set; }

        [JsonProperty("notificationMessages")]
        public NotificationMessages? NotificationMessages { get; set; }
    }
}
