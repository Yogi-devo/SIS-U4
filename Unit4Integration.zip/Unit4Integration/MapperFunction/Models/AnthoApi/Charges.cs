﻿using System.Text.Json.Serialization;

namespace MapperFunction.Models.AnthoApi
{
    public class ChargesApiResponse
    {
        [JsonPropertyName("value")]
        public List<Charges> Value { get; set; }
    }
    public class Charges
    {
        public string Reference { get; set; }
        public string? Type { get; set; }
        public string? Source { get; set; }
        public int TransactionNumber { get; set; }
        public DateTime TransactionDate { get; set; }
        public decimal TransactionAmount { get; set; }
        public string Description { get; set; }
        public string BillingTransactionCode { get; set; }
        public string Status { get; set; }
        public int Id { get; set; }
        public DateTime PostDate { get; set; }
        public DateTime CreatedDateTime { get; set; }
        public Student  Student { get; set; }
        public BankAccount? BankAccount { get; set; }
        public List<ExtendedProperties> ExtendedProperties { get; set; }
        public StudentEnrollmentPeriod StudentEnrollmentPeriod{ get; set; }
        public string Name { get; set; }
        public string? RefundId { get; set; }
        public Campus Campus { get; set; }
        public int AcademicYearSequence { get; set; }
        public string ReceiptNumber { get; set; }
        public StudentAward? StudentAward { get; set; }

    }
    public class StudentEnrollmentPeriod
    {
        public List<AcademicYears> AcademicYears { get; set; }
        public GradeScale GradeScale {  get; set; }
        public ProgramVersion ProgramVersion { get; set; }  

        public decimal AccountReceivableBalance { get; set; }  

        public List<ExtendedProperties> ExtendedProperties { get; set; }
    }

    public class ProgramVersion
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string? Code { get; set; }
    }
    public class AcademicYears
    {
        public int Sequence { get; set; }
        public string StartDate { get; set; }
        public string EndDate { get; set; }
        public string FirstAwardYear { get; set; }

    }
    public class GradeScale
    {
        public string Name { get; set; }
    }
    public class StudentAward
    {
        public FundSource? FundSource { get; set; }
    }
    public class FundSource
    {
        public string? Code { get; set; }
        public string? Name { get; set; }
    }

    public class ExtendedProperties
    {
        public string? Name { get; set; }
        public string? StringValue { get; set; }
    }  

}
