﻿using System.Text.Json.Serialization;

namespace MapperFunction.Models.AnthoApi
{
    public class PaymentApiResponse
    {
        [JsonPropertyName("value")]
        public List<PaymentReceipt> Value { get; set; }
    }
    public class PaymentReceipt
    {
        public string ReceiptNumber { get; set; }
        public string Type { get; set; }
        public string PaymentType { get; set; }
        public decimal AmountPaid { get; set; }
        public string Reference { get; set; }
        public int Id { get; set; }
        public DateTimeOffset ReceiptPrintedDate { get; set; }
        public Student Student { get; set; }
        public BankAccount BankAccount { get; set; }
    }
    public class BankAccount
    {
        public string AccountName { get; set; }
        public string Currency { get; set; }
    }
}
