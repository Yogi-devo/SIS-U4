﻿using System.Text.Json.Serialization;

namespace MapperFunction.Models.AnthoApi
{

    //public class StudentApiResponse
    //{
    //    [JsonPropertyName("value")]
    //    public List<Student> Value { get; set; }
    //}
    //public class Student
    //{
    //    public string StudentNumber { get; set; }

    //    public string StudentId { get; set; }
    //    public string FirstName { get; set; }
    //    public string LastName { get; set; }
    //    public string EmailAddress { get; set; }
    //    public string City { get; set; }
    //    public string PostalCode { get; set; }
    //    public string State { get; set; }
    //    public string StreetAddress { get; set; }       
    //    public string LastNameFirstFour { get; set; }
    //    public string BankAccount { get; set; }
    //    public string BankClearingCode { get; set; }
    //    public string OtherAccount { get; set; }
    //    public string PayMethod { get; set; }
    //    public Country Country { get; set; }
    //    public SchoolStatus SchoolStatus { get; set; }
    //    public string Id { get; set; }
    //    public List<AgencyBranches> AgencyBranches { get; set; }

    //    public Campus Campus { get; set; }
    //}

    //public class Country
    //{
    //    public string Name { get; set; }
    //}

    //public class Campus
    //{
    //    public string Code { get; set; }
    //    public string Name { get; set; } 
    //}

    //public class SchoolStatus
    //{
    //    public string Name { get; set; }
    //}

    //public class NationalityApiResponse
    //{
    //    [JsonPropertyName("value")]
    //    public List<Nationality> Value { get; set; }
    //}
    //public class Nationality
    //{
    //    public int Id { get; set; }
    //    public string Code { get; set; }
    //    public string Name { get; set; }
    //}
    //public class AgencyBranches
    //{
    //    public AgencyBranch AgencyBranch { get; set; }
    //}
    //public class AgencyBranch
    //{
    //    public string? Name { get; set; }
    //}


    public class Student
    {
        [JsonPropertyName("studentNumber")]
        public string StudentNumber { get; set; }

        [JsonPropertyName("id")]
        public string Id { get; set; }

        [JsonPropertyName("firstName")]
        public string FirstName { get; set; }

        [JsonPropertyName("lastName")]
        public string? LastName { get; set; }

        [JsonPropertyName("fullName")]
        public string FullName { get; set; }

        [JsonPropertyName("dateOfBirth")]
        public DateTime? DateOfBirth { get; set; }

        [JsonPropertyName("emailAddress")]
        public string EmailAddress { get; set; }

        [JsonPropertyName("otherEmailAddress")]
        public string OtherEmailAddress { get; set; }

        [JsonPropertyName("phoneNumber")]
        public string PhoneNumber { get; set; }

        [JsonPropertyName("otherPhoneNumber")]
        public string OtherPhoneNumber { get; set; }

        [JsonPropertyName("workPhoneNumber")]
        public string WorkPhoneNumber { get; set; }

        [JsonPropertyName("city")]
        public string City { get; set; }

        [JsonPropertyName("postalCode")]
        public string PostalCode { get; set; }

        [JsonPropertyName("state")]
        public string State { get; set; }

        [JsonPropertyName("streetAddress")]
        public string StreetAddress { get; set; }

        [JsonPropertyName("arBalance")]
        public decimal ArBalance { get; set; }

        [JsonPropertyName("country")]
        public Country Country { get; set; }

        [JsonPropertyName("schoolStatus")]
        public SchoolStatus SchoolStatus { get; set; }

        [JsonPropertyName("campus")]
        public Campus Campus { get; set; }

        [JsonPropertyName("agencyBranches")]
        public List<AgencyBranches> AgencyBranches { get; set; }

        [JsonPropertyName("studentBankAccounts")]
        public List<StudentBankAccount> StudentBankAccounts { get; set; }
    }

    public class Country
    {
        [JsonPropertyName("name")]
        public string Name { get; set; }
    }

    public class SchoolStatus
    {
        [JsonPropertyName("name")]
        public string Name { get; set; }
    }

    public class Campus
    {
        [JsonPropertyName("id")]
        public int Id { get; set; }

        [JsonPropertyName("code")]
        public string Code { get; set; }

        [JsonPropertyName("name")]
        public string Name { get; set; }
    }

    public class AgencyBranches
    {
        [JsonPropertyName("agencyBranch")]
        public AgencyBranch AgencyBranch { get; set; }
    }

    public class AgencyBranch
    {
        public int? Id { get; set; }

        [JsonPropertyName("name")]
        public string Name { get; set; }
        public Agency? Agency { get; set; }
    }

    public class Agency
    {
        public int? Id { get; set; }
        public string? Code { get; set; }
        public string? Name { get; set; }
    }


    public class StudentBankAccount
    {
        [JsonPropertyName("id")]
        public int Id { get; set; }

        [JsonPropertyName("accountNumber")]
        public string AccountNumber { get; set; }

        [JsonPropertyName("initializationVector")]
        public string InitializationVector { get; set; }

        [JsonPropertyName("accountType")]
        public string AccountType { get; set; }

        [JsonPropertyName("bankName")]
        public string BankName { get; set; }

        [JsonPropertyName("routingNumber")]
        public string RoutingNumber { get; set; }

        [JsonPropertyName("studentId")]
        public int StudentId { get; set; }

        [JsonPropertyName("transactionType")]
        public string TransactionType { get; set; }

        [JsonPropertyName("extendedProperties")]
        public List<ExtendedProperty> ExtendedProperties { get; set; }

        public string NameOnAccount => ExtendedProperties?
        .FirstOrDefault(ep => ep.Name == "Name on the Account")?.StringValue;

        public string ExtendedAccountNumber => ExtendedProperties?
            .FirstOrDefault(ep => ep.Name == "Account Number")?.StringValue;

        public string SwiftCode => ExtendedProperties?
            .FirstOrDefault(ep => ep.Name == "BIC Number or SWIFT Code")?.StringValue;

        public string IbanNumber => ExtendedProperties?
            .FirstOrDefault(ep => ep.Name == "IBAN Number")?.StringValue;
        public string SortCode => ExtendedProperties?
            .FirstOrDefault(ep => ep.Name == "Sort Code")?.StringValue;
    }

    public class ExtendedProperty
    {
        [JsonPropertyName("id")]
        public int Id { get; set; }

        [JsonPropertyName("name")]
        public string Name { get; set; }

        [JsonPropertyName("stringValue")]
        public string StringValue { get; set; }
    }

}
