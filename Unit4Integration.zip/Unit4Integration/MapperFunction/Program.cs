using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using MapperFunction.Config;
using MapperFunction.Services;
using MapperFunction.Models;
using MapperFunction.Interfaces;
using Microsoft.Extensions.Configuration;

var host = new HostBuilder()
    .ConfigureFunctionsWebApplication()
    .ConfigureServices(services =>
    {
        services.AddApplicationInsightsTelemetryWorkerService();
        services.ConfigureFunctionsApplicationInsights();

        services.AddTransient<IUnit4ApiService, Unit4ApiService>();
        services.AddTransient<ISftpClient, Unit4SftpClient>();
        services.AddTransient<MailService>();
        services.AddOptions<SftpConfig>()
        .Configure<IConfiguration>((settings, configuration) =>
        {
            configuration.GetSection(nameof(SftpConfig)).Bind(settings);
        });
        services.AddOptions<Lg04Values>()
       .Configure<IConfiguration>((settings, configuration) =>
       {
           configuration.GetSection(nameof(Lg04Values)).Bind(settings);
       });
        services.AddOptions<Creden>()
       .Configure<IConfiguration>((settings, configuration) =>
       {
           configuration.GetSection(nameof(Creden)).Bind(settings);
       });
        services.AddOptions<Mail>()
      .Configure<IConfiguration>((settings, configuration) =>
      {
          configuration.GetSection(nameof(Mail)).Bind(settings);
      });
    })
    .Build();

host.Run();
