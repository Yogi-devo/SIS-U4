﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MapperFunction.Interfaces
{
    public interface ISftpClient
    {
        void UploadFile(string sourceFilePath, string targetFilePath);
    }
}
