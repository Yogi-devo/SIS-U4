﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Azure.Storage.Blobs;
using MapperFunction.Models;
using MapperFunction.Models.Unit4Api;

namespace MapperFunction.Interfaces
{
    public interface IUnit4ApiService
    {       
        Task SyncStudentData(DateTime? lastRunTime);
        Task<List<Lg04Row>> FetchChargesFromAnthology(DateTime? lastRunTime);        
        Task LogErrorToBlob(BlobContainerClient logFileContainer, Exception ex);
    }
}
