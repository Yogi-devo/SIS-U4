using Azure.Storage.Blobs;
using MapperFunction.Config;
using MapperFunction.Interfaces;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;


namespace MapperFunction
{    
    public class Mapper()
    {
        private readonly IConfiguration _configuration;
        private readonly ILogger<Mapper> _logger;
        private readonly BlobServiceClient _blobServiceClient;
        private readonly BlobContainerClient _logFileContainer;
        private readonly IUnit4ApiService _unit4ApiService;

        public Mapper(IConfiguration configuration, ILogger<Mapper> logger, IUnit4ApiService unit4ApiService, Interfaces.ISftpClient sftpClient, IOptions<FeatureFlags> featureFlags)
            : this()
        {
            _unit4ApiService = unit4ApiService;
            _configuration = configuration;
            _logger = logger;
            _blobServiceClient = new BlobServiceClient(configuration["Storage:StorageAccountConnectionString"]);
            _logFileContainer = _blobServiceClient.GetBlobContainerClient(configuration["Log:LogFileContainer"]);
        }

        [Function("Mapper")]
        public async Task Run([TimerTrigger("%FunctionSchedule%", RunOnStartup = false)] TimerInfo myTimer)
        {
            try
            {
                DateTime? lastRunTime = myTimer.ScheduleStatus?.Last; // YY Azure fn give it in UTC format

                DateTime formattedLastRunTime = DateTime.MinValue; 

                if (lastRunTime.HasValue)
                {
                    //--- For running locally using Visual Studio(In India) ---

                    //TimeZoneInfo indiaTimeZone = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
                    //DateTime istTime = DateTime.SpecifyKind(lastRunTime.Value, DateTimeKind.Unspecified);
                    //DateTime utcTime = TimeZoneInfo.ConvertTimeToUtc(istTime, indiaTimeZone);
                    //TimeZoneInfo newYorkTimeZone = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
                    //formattedLastRunTime = TimeZoneInfo.ConvertTimeFromUtc(utcTime, newYorkTimeZone);

                    //--- For deployment at azure ---

                    DateTime utcTime = DateTime.SpecifyKind(lastRunTime.Value, DateTimeKind.Utc);
                    TimeZoneInfo newYorkTimeZone = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
                    formattedLastRunTime = TimeZoneInfo.ConvertTimeFromUtc(utcTime, newYorkTimeZone);

                    Console.WriteLine($"UTC Time: {utcTime}");
                    Console.WriteLine($"New York Time: {formattedLastRunTime}");

                }

                _logger.LogInformation($"Mapper Function execution started at: {DateTime.Now}");
                //y  await _unit4ApiService.SyncStudentData(formattedLastRunTime);    
                  await _unit4ApiService.FetchChargesFromAnthology(formattedLastRunTime);                               
               _logger.LogInformation($"Mapper Function execution completed at: {DateTime.Now}");
            }
            catch (Exception ex)
            {
                await _unit4ApiService.LogErrorToBlob(_logFileContainer, ex);
                _logger.LogError(ex, "Error occurred while executing Mapper function.");
            }
        }
    }
}
