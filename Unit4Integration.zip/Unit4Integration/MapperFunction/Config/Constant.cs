﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MapperFunction.Config
{
    public static class Constant
    {
        public const string Subject = "Student/Customer not added in Unit4";
        public const string Body = "Some error or exception occurred during addition of Student/Customer in Unit4, Please examine the attached file for details";
        public static class Email
        {
            public const string Subject = "Student/Customer not added in Unit4";
            public const string Body = "Some error or exception occurred during addition of Student/Customer in Unit4, Please examine the attached file for details";
        }
    }
}
