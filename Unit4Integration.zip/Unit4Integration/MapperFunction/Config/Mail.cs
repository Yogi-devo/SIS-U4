﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MapperFunction.Config
{
    public class Mail
    {        
        public List<string> RecipientEmails { get; set; } = new();
        public int MailPort { get; set; } = 22;
        public required string MailServer { get; set; }
        public required string Subject { get; set; }
        public required string SenderEmail { get; set; }
        public required string SenderPassword { get; set; }
    }
}
