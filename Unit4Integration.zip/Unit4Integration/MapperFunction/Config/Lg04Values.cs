﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MapperFunction.Config
{
    public class Lg04Values
    {
        public required string BaseBatchId { get; set; }
        public required string Client { get; set; }
        public required string VoucherType { get; set; }
        public required int SequenceNo { get; set; }
        public required string Responsible1 { get; set; }
        public required string Responsible2 { get; set; }
        public required string TransType { get; set; }
        public required int LineNoHeader { get; set; }
        public required int AmountSet { get; set; }
        public required int LineNoValue { get; set; }         
        public required string Article { get; set; }
        public required string Att1Id { get; set; }
        public required string Att2Id { get; set; }
        public required string Att3Id { get; set; }
        public required string Att4Id { get; set; }
        public required string Att5Id { get; set; }
        public required string Att6Id { get; set; }
        public required string Att7Id { get; set; }

    }
}
