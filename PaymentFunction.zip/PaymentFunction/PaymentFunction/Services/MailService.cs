﻿using Azure.Storage.Blobs;
using Microsoft.Extensions.Configuration;
using MailKit.Net.Smtp;
using MimeKit;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;

namespace PaymentFunction.Services
{
    public class MailService
    {
        private readonly IConfiguration _configuration;

        public MailService(IConfiguration configuration)
        {
            _configuration = configuration;
        }



        public async Task<bool> SendEmailAsync(string subject, string? body )
        {
            try
            {
                var recipientEmails = _configuration["Mail:RecipientEmails"]
                         .Split(',', StringSplitOptions.RemoveEmptyEntries)
                         .Select(email => email.Trim())  // Trim any spaces
                         .ToList();
                //string body = "Some error or exception occurred during addition of Student/Customer in Unit4, Please examine the attached file for details";

                var emailSettings = _configuration.GetSection("EmailSettings");
                string mailServer = _configuration["Mail:MailServer"]; 
                int mailPort = int.Parse(_configuration["Mail:MailPort"]);// 587; 
                string senderEmail = _configuration["Mail:SenderEmail"];
                string senderPassword = _configuration["Mail:SenderPassword"];
                string storageConnectionString = _configuration["Storage:StorageAccountConnectionString"];
                string containerName = _configuration["UnmatchCustomer:UnmatchCustomerContainer"];

                string blobFile1 = $"{DateTime.Now:yyyyMMdd}_MultipleUnmatchedCustomer.log";
                string blobFile2 = $"{DateTime.Now:yyyyMMdd}_NoUnmatchedCustomer.log";

                // Retrieve files from Azure Blob Storage
                string fileContent1 = await GetBlobFileContentAsync(storageConnectionString, containerName, blobFile1);
                string fileContent2 = await GetBlobFileContentAsync(storageConnectionString, containerName, blobFile2);

                // If no attachments, return without sending email
                if (string.IsNullOrEmpty(fileContent1) && string.IsNullOrEmpty(fileContent2))
                {
                    return false;
                }

                var emailMessage = new MimeMessage();
                emailMessage.From.Add(new MailboxAddress("Unit4 Mapper Service", senderEmail));

                foreach (var recipient in recipientEmails)
                {
                    emailMessage.To.Add(new MailboxAddress("", recipient));
                }
                emailMessage.Subject = subject;

                var multipart = new MimeKit.Multipart("mixed");

                var textPart = new TextPart("html")
                {
                    Text = body // "Some error or exception occurred during addition of Student/Customer in Unit4, Please examine the attached files for details"
                };
                multipart.Add(textPart);

                // Attach files if content exists
                if (!string.IsNullOrEmpty(fileContent1))
                {
                    var attachment1 = new MimePart("text", "plain")
                    {
                        Content = new MimeContent(new MemoryStream(Encoding.UTF8.GetBytes(fileContent1))),
                        ContentDisposition = new ContentDisposition(ContentDisposition.Attachment),
                        ContentTransferEncoding = ContentEncoding.Base64,
                        FileName = blobFile1
                    };
                    multipart.Add(attachment1);
                }

                if (!string.IsNullOrEmpty(fileContent2))
                {
                    var attachment2 = new MimePart("text", "plain")
                    {
                        Content = new MimeContent(new MemoryStream(Encoding.UTF8.GetBytes(fileContent2))),
                        ContentDisposition = new ContentDisposition(ContentDisposition.Attachment),
                        ContentTransferEncoding = ContentEncoding.Base64,
                        FileName = blobFile2
                    };
                    multipart.Add(attachment2);
                }

                emailMessage.Body = multipart;

                using var smtpClient = new SmtpClient();
                await smtpClient.ConnectAsync(mailServer, mailPort, MailKit.Security.SecureSocketOptions.StartTls);
                await smtpClient.AuthenticateAsync(senderEmail, senderPassword);
                await smtpClient.SendAsync(emailMessage);
                await smtpClient.DisconnectAsync(true);

                return true;
            }
            catch
            {
                return false;
            }
        }

        private async Task<string> GetBlobFileContentAsync(string connectionString, string containerName, string blobName)
        {
            try
            {
                var blobServiceClient = new BlobServiceClient(connectionString);
                var blobContainerClient = blobServiceClient.GetBlobContainerClient(containerName);
                var blobClient = blobContainerClient.GetBlobClient(blobName);

                if (await blobClient.ExistsAsync())
                {
                    var response = await blobClient.DownloadContentAsync();
                    return response.Value.Content.ToString();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error retrieving blob file: {ex.Message}");
            }
            return string.Empty;
        } 
    }
}
