﻿using PaymentFunction.Models.Unit4Api;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PaymentFunction.Services
{
    public class EmailService
    {

        //To Do..............

    }
}
