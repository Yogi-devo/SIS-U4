﻿using PaymentFunction.Interfaces;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System.Net.Http.Headers;
using System.Text;
using PaymentFunction.Models.AnthoApi;
using PaymentFunction.Models;
using CsvHelper;
using PaymentFunction.Infrastructure;
using Microsoft.Extensions.Logging;
using System.Globalization;
using ISftpClient = PaymentFunction.Interfaces.ISftpClient;
using Azure.Storage.Blobs;
using PaymentFunction.Config;
using Microsoft.Extensions.Options;
using PaymentFunction.Models.Unit4Api;
using System.Net.Http.Json;
using System.Net;
using PaymentFunction.Services;

namespace MapperFunction.Services
{
    public class Unit4ApiService : IUnit4ApiService
    {
        private static HttpClient SharedHttpClient;
        private readonly ISftpClient _sftpClient;
        private readonly IConfiguration _configuration;
        private readonly Gl07Values _gl07Values;
        private readonly Creden _creden;
        private readonly string _u4authToken;
        private readonly ILogger _logger;
        private readonly MailService _mailService;
        public Unit4ApiService(IConfiguration configuration, ISftpClient sftpClient, IOptions<Gl07Values> gl07Values, IOptions<Creden> creden, ILoggerFactory loggerFactory, MailService mailService)
        {
            _logger = loggerFactory.CreateLogger<Unit4ApiService>();
            SharedHttpClient = new HttpClient
            {
                BaseAddress = new Uri(configuration.GetValue<string>("Unit4Api:BaseUrl"))
            };

            if (!SharedHttpClient.BaseAddress.AbsoluteUri.EndsWith("/"))
            {
                SharedHttpClient.BaseAddress = new Uri(SharedHttpClient.BaseAddress.AbsoluteUri + "/");
            }
            _configuration = configuration;
            _sftpClient = sftpClient;
            _gl07Values = gl07Values.Value;
            _creden = creden.Value;
            _mailService = mailService;
            var targetFilePath = _configuration["SftpConfig:Hostname"];
            var authToken = Convert.ToBase64String(Encoding.UTF8.GetBytes($"{_creden.AnthologyUsername}:{_creden.AnthologyPassword}"));
            SharedHttpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", authToken);
            _u4authToken = Convert.ToBase64String(Encoding.UTF8.GetBytes($"{_creden.Unit4Username}:{_creden.Unit4Password}"));

            BlobServiceClient blobServiceClient = new BlobServiceClient(_configuration["Storage:StorageAccountConnectionString"]);
            BlobContainerClient createFileContainer = blobServiceClient.GetBlobContainerClient(_configuration["File:CreateFileContainer"]);
            BlobContainerClient logFileContainer = blobServiceClient.GetBlobContainerClient(_configuration["Log:LogFileContainer"]);
        }
       
        /// <summary>
        /// This Method is used for generating Unique BatchId.
        /// </summary>
        /// <param name="baseString"> Providing baseString as parameter  during execution</param>
        /// <returns>It will return the unique BatchId for each iteration.</returns>
        public string GenerateUniqueBatch(string baseString)
        {
            DateTime now = DateTime.Now;
            string dateTimePart = $"{now:yyyyMMdd_HHmm}";
            return $"{baseString}_{dateTimePart}";
        }

        private string GetLEGENTITY(string campusName)
        {
            return campusName?.ToLowerInvariant() switch
            {               
                "madrid" => "KIPSIUSPA",
                "heidelberg" => "KIPSIUGER",
                "paris" => "KIPSIUFRA",
                "usa" => "KIPSIUUSA",
                "florida" => "KIPSIUUSA",
                "distance learning" => "KIPSIUUSA", 
                _ => "KIPSIUUSA"
            };
        }

        private string GetExtendedProperties(string? costCenter ,string? campusCode)
        {
            try
            {                
                    return campusCode?.ToLowerInvariant() switch
                    {
                        "spa" => "1930001",
                        "madrid" => "1930001",
                        "ger" => "1920001",
                        "heidelberg" => "1920001",
                        "hd" => "1920001",
                        "fra" => "1940001",
                        "paris" => "1940001",
                        "usa" => "1910001",
                        "florida" => "1910101",
                        "dl" => "1910200",
                        "hq" => "1910001",
                        _ => "1910001" // Default 
                    };              
            }
            catch (Exception ex)
            {
                throw new Exception("An error occurred while getting extended properties.", ex);
            }
        }

        private string GetCurrencyCode(string campusName)
        {
            try
            {
                return campusName?.ToLowerInvariant() switch
                {
                    "madrid" => "EUR",
                    "heidelberg" => "EUR",
                    "paris" => "EUR",
                    "usa" => "USD",
                    "hq" => "USD",
                    "florida" => "USD",
                    "dl" => "USD",
                    _ => "USD"
                };
            }
            catch (Exception)
            {
                throw;
            }

        }
                
        public string GetGradeScale(string? gradeScaleName, string studentNumber, string? agencyId)
        {
            if (!string.IsNullOrWhiteSpace(agencyId))
            {
                return studentNumber;
            }
            else
            {
                return string.Empty;
            }
        }

        public string? GetExtInvRef(string? CheckNumber, string? Reference, string? extId)
        {
            if (string.IsNullOrEmpty(CheckNumber) && string.IsNullOrEmpty(Reference))
                return extId;

            if (string.IsNullOrEmpty(Reference))
                return CheckNumber ?? string.Empty;

            if (string.IsNullOrEmpty(CheckNumber))
                return Reference;

            return $"{CheckNumber} - {Reference}";

        }
 

        /// <summary>
        /// This method is used for finding academic year in "YYYY-YY" format
        /// </summary>
        /// <param name="academicYears, academicYearSequence"></param>
        /// <returns>string</returns>       
        private static string GetAcademicYear(List<AcademicYears> academicYears, int? academicYearSequence)
        {
            try
            {
                if (academicYears == null || academicYearSequence == null || academicYearSequence <= 0)
                {
                    return "APP";
                }
                var selectedYear = academicYears.FirstOrDefault(ay => ay.Sequence == academicYearSequence)?.FirstAwardYear;
                if (selectedYear != null)
                {
                    return selectedYear;
                }                
                return "APP";
            }
            catch (Exception)
            {
                throw;
            }            
        }

        public string? GetBankAccount(string? accountName, string? campusCode)
        {
            if (!string.IsNullOrEmpty(accountName))
            {
                var result = accountName.ToLowerInvariant() switch
                {
                    "volksbank kurpfalz eg" => "192020",
                    "lacaixa" => "191040",
                    "cic" => "191010",
                    "pacwest 2073" => "191142",
                    "intercampus - fla" => "192100",
                    "intercampus - mad" => "192110",
                    "intercampus - par" => "192120",
                    "intercampus - hdb" => "192130",

                    _ => null
                };

                if (!string.IsNullOrEmpty(result))
                    return result;
            }

            if (!string.IsNullOrEmpty(campusCode))
            {
                return campusCode.ToLowerInvariant() switch
                {
                    "hd" => "192020",
                    "madrid" => "191040",
                    "paris" => "191143",
                    "florida" => "191142",
                    "dl" => "191142",
                    "hq" => "191142",
                    _ => null
                };
            }
            return null;
        }

        public string GetAparId(string studentNumber, string? agencyId)
        {
            return string.IsNullOrWhiteSpace(agencyId) ? studentNumber : agencyId;
        }

        /// <summary>
        /// Fetch the payment data from Anthology ERP.
        /// </summary>
        /// <param name="null">Not providing any parameter but during execution it will call Anthology GET API which is provided by Anthology</param>
        /// <returns>It will return the List of all payment data as per its criteria in Gl07Row format .</returns>
        /// <exception >Exception may occur during mapping of field values of 'paymentData' into  Gl07Row object </exception>
        public async Task<List<Gl07Row>> FetchPaymentFromAnthology(DateTime? lastRunTime)
        {
            BlobServiceClient blobServiceClient = new BlobServiceClient(_configuration["Storage:StorageAccountConnectionString"]);
            BlobContainerClient createFileContainer = blobServiceClient.GetBlobContainerClient(_configuration["File:CreateFileContainer"]);
            BlobContainerClient logFileContainer = blobServiceClient.GetBlobContainerClient(_configuration["Log:LogFileContainer"]);
            BlobContainerClient unmatchCustomerContainer = blobServiceClient.GetBlobContainerClient(_configuration["UnmatchCustomer:UnmatchCustomerContainer"]);
            long? voucherRef = null;
            int? sequenceNumber = null;
            try
            {
                string currentDate =   "2025-10-23T00:00:00Z"; // DateTime.UtcNow.ToString("yyyy-MM-ddT00:00:00Z");   // "2025-05-30T00:00:00Z"; //
                // string paymentApi = $@"https://sisclientweb-test-101053.campusnexus.cloud/ds/campusnexus/StudentAccountTransactions?$filter=(Type eq 'P') and (CreatedDateTime gt {currentDate})&$select=StudentId,ReceiptNumber,AcademicYearSequence,Type,PaymentType,AmountPaid,Reference,CheckNumber,Id,PostDate,TransactionNumber,TransactionAmount,CreatedDateTime,BillingTransactionCode,Status,Description,TransactionDate,RefundId,ReceiptPrintedDate&$expand=Term($select=Id,Name),Campus($select=Id,Name,Code),Student($select=Id,StudentNumber,ArBalance;$expand=AgencyBranches($select=Id;$expand=AgencyBranch($select=Id,Name))),StudentEnrollmentPeriod($select=Id,EnrollmentNumber,AccountReceivableBalance;$expand=ProgramVersion($select=Id,Name;$expand=Degree($select=Id,Name)),GradeScale($select=Id,Code,Name),AcademicYears($select=Id,AcademicYearId,Sequence,StartDate,EndDate,FirstAwardYear)),BankAccount($select=AccountName,Currency),ExtendedProperties($select=Name,StringValue)";
                string paymentApi = _configuration["AnthologyConfig:Payment"].Replace("{currentDate}", currentDate, StringComparison.OrdinalIgnoreCase);
                var paymentResponse = await SharedHttpClient.GetStringAsync(paymentApi);
                //y var paymentResponse = await SharedHttpClient.GetStringAsync(_configuration["AnthologyConfig:Payment"]);
                var paymentData = JsonConvert.DeserializeObject<PaymentApiResponse>(paymentResponse);
                                
                string paymentApiFA = _configuration["AnthologyConfig:PaymentFA"].Replace("{currentDate}", currentDate, StringComparison.OrdinalIgnoreCase);
                 var paymentResponseFA = await SharedHttpClient.GetStringAsync(paymentApiFA);
                //y var paymentResponseFA = await SharedHttpClient.GetStringAsync(_configuration["AnthologyConfig:PaymentFA"]);
                var paymentDataFA = JsonConvert.DeserializeObject<PaymentApiResponse>(paymentResponseFA);

                //Logic for combine two API response into one.....
                var paymentDataFADict = paymentDataFA.Value.ToDictionary(
                    cfa => new
                    {
                        cfa.Student.StudentNumber,
                        cfa.TransactionNumber,
                        cfa.TransactionAmount,
                        cfa.TransactionDate,
                        cfa.Source,
                        cfa.Type
                    },
                    cfa => cfa
                );

                // Prepare the final combined response
                var paymentDataFinal = new PaymentApiResponse
                {
                    Value = new List<PaymentReceipt>()
                };

                foreach (var charge in paymentData.Value)
                {
                    // Create the key for lookup in paymentDataFA dictionary
                    var key = new
                    {
                        charge.Student.StudentNumber,
                        charge.TransactionNumber,
                        charge.TransactionAmount,
                        charge.TransactionDate,
                        charge.Source,
                        charge.Type
                    };

                    if (paymentDataFADict.TryGetValue(key, out var matchedChargeFA))
                    {
                        // If match found, copy StudentAward from matched record
                        charge.StudentAward = matchedChargeFA.StudentAward;
                    }

                    paymentDataFinal.Value.Add(charge);
                }
                //Logic for combine two API end.....

             //y   paymentDataFinal.Value = paymentDataFinal.Value.Where(y => y.CreatedDateTime > lastRunTime).ToList();

                paymentDataFinal.Value = paymentDataFinal.Value.Where(y => y.Source != "F" && !new[]
                {
                  "2324 PEL", "DLGPL", "DIRPLUS", "DIRSUB", "DIRUNSUB",
                  "PELL", "PRIVATEL", "SEOG", "SEOGMAT", "C33VB", "VAVOCREH"
                }.Contains(y.StudentAward?.FundSource?.Code)).ToList();
                // paymentData.Value = paymentData.Value.Where(y => y.TransactionAmount == 3000).ToList();

                if (paymentDataFinal.Value.Count > 0)
                {
                    string payCount = paymentDataFinal.Value.Count().ToString();
                    await LogSuccessToBlob(null, logFileContainer, payCount);
                    List<Gl07Row> gl07Output = new List<Gl07Row>();
                    List<Gl07Row> gl07ForLog = new List<Gl07Row>();
                    long voucherNo = 0;
                    string baseString = _gl07Values.BaseBatchId;
                    string generatedBatchId = GenerateUniqueBatch(baseString);
                   // var unmatchedTransactions = await GetUnmatchCustomerTransactionsAsync();

                    foreach (var pay in paymentDataFinal.Value)
                    {
                        try
                        {
                            var academicYear = GetAcademicYear(pay.StudentEnrollmentPeriod?.AcademicYears, pay.AcademicYearSequence);
                           
                            //if (unmatchedTransactions != null && unmatchedTransactions.Count > 0)
                            //{   
                            //    var transactionResult = await ProcessUnmatchedCustomerTransactionsAsync(pay.Student.StudentNumber.ToString(), unmatchedTransactions, academicYear);
                            //    if (transactionResult != null)
                            //    {
                            //        voucherRef = transactionResult.TransactionNumber;
                            //        sequenceNumber = transactionResult.SequenceNumber;
                            //    }
                            //    else 
                            //    {
                            //        voucherRef = null;
                            //        sequenceNumber = null;
                            //    }
                            //}
                            
                            voucherNo++;
                            string convertedAmount = (pay.TransactionAmount * 100).ToString("F0"); 
                            decimal Amount = decimal.Parse(convertedAmount);
                            string currency = GetCurrencyCode(pay.Campus?.Name);
                            string legentity = GetLEGENTITY(pay.Campus?.Name);                           
                            var levelOfStudy = GetGradeScale(pay.StudentEnrollmentPeriod?.GradeScale?.Name, pay.Student.StudentNumber.ToString(), pay.Student.AgencyBranches?.FirstOrDefault()?.AgencyBranch?.Id.ToString());
                            string extInvRef = GetExtInvRef(pay.CheckNumber, pay.Reference, pay.Id.ToString());
                            var description = $"{pay.Description ?? string.Empty}: #{pay.ReceiptNumber ?? string.Empty}".Trim(':', '#', ' ');
                            string costCenter = GetExtendedProperties(pay.ExtendedProperties?.FirstOrDefault()?.StringValue, pay.Campus?.Code);
                            string bankAccount = GetBankAccount(pay.BankAccount?.AccountName, pay.Campus?.Code);                            
                            string aparId = GetAparId(pay.Student.StudentNumber.ToString(), pay.Student.AgencyBranches?.FirstOrDefault()?.AgencyBranch?.Agency?.Code);


                            var gl07Row1 = new Gl07Row
                            {
                                BatchId = generatedBatchId,
                                Interface = _gl07Values.Interface,
                                VoucherType = _gl07Values.VoucherType,
                                TransType = _gl07Values.TransTypeHeader,
                                Client = _gl07Values.Client,
                                AparId = aparId,                                
                                VoucherNo = voucherNo,
                                
                                Account =  _gl07Values.AccountDebt, 
                                Dim1 = costCenter,
                                Dim2 = academicYear, 
                                Dim3 = pay.BillingTransactionCode,
                                Dim5 = pay.Campus?.Code, 
                                Dim6 = levelOfStudy,
                                Dim7 = legentity, 
                                TaxCode = _gl07Values.TaxCode,
                                Description = description,
                                Currency = pay.BankAccount.Currency ?? currency,
                                CurAmount = GetNegativeValue(Amount),
                                Amount = GetNegativeValue(Amount),
                                VoucherDate = pay.TransactionDate.GetValueOrDefault().ToString("yyyyMMdd") ?? string.Empty,
                                TransDate = pay.TransactionDate.GetValueOrDefault().ToString("yyyyMMdd") ?? string.Empty,
                                ExtInvRef = extInvRef,
                                //VoucherRef = voucherRef ,
                                //SequenceRef =  sequenceNumber ,
                                AparType = _gl07Values.AparType,
                                Status = _gl07Values.Status,
                            };
                            var gl07Row2 = new Gl07Row
                            {
                                BatchId = generatedBatchId,
                                Interface = _gl07Values.Interface,
                                VoucherType = _gl07Values.VoucherType,
                                TransType = _gl07Values.TransTypeValue,
                                Client = _gl07Values.Client,
                                AparId = pay.Student.StudentNumber.ToString(),
                                VoucherNo = voucherNo,
                                //Period = 0 , // pay.TransactionDate.HasValue ? Convert.ToInt64(pay.TransactionDate) : null,
                                Account = bankAccount,   
                                Dim1 = costCenter,
                                Dim5 = pay.Campus?.Code, 
                                Dim7 = legentity, 
                                TaxCode = _gl07Values.TaxCode,
                                Description = description, 
                                Currency = pay.BankAccount.Currency ?? currency,
                                CurAmount = Amount,
                                Amount = Amount,
                                VoucherDate = pay.TransactionDate.GetValueOrDefault().ToString("yyyyMMdd") ?? string.Empty,
                                TransDate = pay.TransactionDate.GetValueOrDefault().ToString("yyyyMMdd") ?? string.Empty,
                                Status = _gl07Values.Status,
                            };
                            gl07Output.Add(gl07Row1);
                            gl07Output.Add(gl07Row2);
                            gl07ForLog.Add(gl07Row2);
                        }
                        catch (Exception ex)
                        {
                            LogErrorToBlob(pay.Student.StudentNumber.ToString(), pay.Campus?.Code, pay.TransactionAmount, logFileContainer, ex);
                            Console.WriteLine($"Error occurred during processing payment with Id: {pay.Student.StudentNumber.ToString()}. Exception: {ex.Message}");
                            
                        }
                    }
                    LogSuccessToBlob(gl07ForLog, logFileContainer, gl07ForLog.Count.ToString());
                    var fixedLengthItems = new FixedWidthLinesProvider<Gl07Row>().Write(gl07Output);
                    // Convert lg04Output to CSV format
                    var csvData = new StringBuilder();
                    using (var writer = new StringWriter(csvData))
                    using (var csv = new CsvWriter(writer, CultureInfo.InvariantCulture))
                    {
                        csv.WriteHeader<Gl07Row>();
                        csv.NextRecord();
                        csv.WriteRecords(gl07Output);
                    }
                    string txtBlobName = $"{generatedBatchId}.txt";
                    string csvBlobName = $"{generatedBatchId}.csv";

                    BlobClient txtBlobClient = createFileContainer.GetBlobClient(txtBlobName);
                    using (var stream = new MemoryStream(Encoding.UTF8.GetBytes(string.Join("\n", fixedLengthItems))))
                    {
                        await txtBlobClient.UploadAsync(stream, true);
                    }

                    BlobClient csvBlobClient = createFileContainer.GetBlobClient(csvBlobName);
                    using (var stream = new MemoryStream(Encoding.UTF8.GetBytes(csvData.ToString())))
                    {
                        await csvBlobClient.UploadAsync(stream, true);
                    }

                    string txtFileBlobUri = txtBlobClient.Uri.ToString();
                    string csvFileBlobUri = csvBlobClient.Uri.ToString();
                    Console.WriteLine($"Text file for payment saved at {txtFileBlobUri}");
                    Console.WriteLine($"CSV file for payment saved at {csvFileBlobUri}");
                    _logger.LogInformation($"Text file for payment saved at {txtFileBlobUri}", $"CSV file for payment saved at {csvFileBlobUri}");

                    _sftpClient.UploadFile(txtFileBlobUri, txtBlobName);
                    string sftpMessage = $"SFTP successfully transfer text file {txtBlobName}";
                    await LogSftpToBlob(logFileContainer, sftpMessage);
                    _logger.LogInformation(sftpMessage);
                    Console.WriteLine(sftpMessage);
                }
                else
                {
                    Exception ex = new Exception($"No data found in 'Payment API' response for provided Date and time {DateTime.UtcNow}");
                    LogErrorToBlob(logFileContainer, ex);
                    Console.WriteLine($"No data found in payment API response for provided Date and time {DateTime.UtcNow}");
                    _logger.LogError(ex, "No Data found in anthology Payment API response");
                }
                string subject = "No unmatched customer transactions/Multiple unmatched customer transactions found";
                string body = "Multiple unmatched transactions/No unmatched transactions found for few transaction in Unit4 during GL07 file creation, Please examine the attached file for details";

                //bool emailSent = await _mailService.SendEmailAsync(subject, body);
                //if (emailSent)
                //{
                //    Console.WriteLine("Email sent successfully!");
                //}
            }
            catch (Exception ex)
            {
                LogErrorToBlob(logFileContainer, ex);
                throw;
            }
            return new List<Gl07Row>(); // Return empty list if no data
        }


        /// <summary>
        /// This method will fetch all Unmatch Customer Transactions.
        /// </summary>
        /// <returns>It will return CustomerTransaction type</returns>
        /// <exception cref="HttpRequestException"></exception>
        public async Task<List<CustomerTransaction>> GetUnmatchCustomerTransactionsAsync()
        {
            BlobServiceClient blobServiceClient = new BlobServiceClient(_configuration["Storage:StorageAccountConnectionString"]);            
            BlobContainerClient logFileContainer = blobServiceClient.GetBlobContainerClient(_configuration["Log:LogFileContainer"]);
            try
            {

                SharedHttpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", _u4authToken);

                var requestUrl = $"{_configuration["Unit4Api:BaseUrl2"]}/objects/customer-transactions?unmatchedCustomerInvoices=true&matchedCustomerInvoices=false&companyId=US1";
                var response = await SharedHttpClient.GetAsync(requestUrl);
                if (response.IsSuccessStatusCode)
                {
                    // Parse and return the response
                    var customerTransactions = await response.Content.ReadFromJsonAsync<List<CustomerTransaction>>();
                    return customerTransactions ?? new List<CustomerTransaction>();
                }
                else if (response.StatusCode == HttpStatusCode.NotFound)
                {
                    _logger.LogWarning($"No unmatched customer transactions found at the specified endpoint: {requestUrl}");
                    return new List<CustomerTransaction>();
                }
                else if (response.StatusCode == HttpStatusCode.Unauthorized)
                {
                    throw new HttpRequestException("Unauthorized access - check your API credentials.");
                }
                else
                {
                    var responseBody = await response.Content.ReadAsStringAsync();
                    throw new HttpRequestException($"Invalid response status code: {response.StatusCode}. Response body: {responseBody}");
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error while fetching unmatched customer transactions: {ex.Message}");
                LogErrorToBlob(logFileContainer, ex);
                return new List<CustomerTransaction>();
            }
        }


        /// <summary>
        /// This method Process Unmatched Customer Transactions 
        /// </summary>
        /// <param name="customerId"></param>
        /// <param name="BillingTransactionCode"></param>
        /// <param name="unmatchedTransactions"></param>
        /// <returns>It returns CustomerTransaction type</returns>
        public async Task<CustomerTransaction?> ProcessUnmatchedCustomerTransactionsAsync(string customerId, List<CustomerTransaction> unmatchedTransactions, string? acadmicYear)
        {
            BlobServiceClient blobServiceClient = new BlobServiceClient(_configuration["Storage:StorageAccountConnectionString"]);
            BlobContainerClient unmatchCustomerContainer = blobServiceClient.GetBlobContainerClient(_configuration["UnmatchCustomer:UnmatchCustomerContainer"]);

            try
            {
                var unmatchedTransactionsForCustomer = unmatchedTransactions.Where(x => x.Invoice.CustomerId == customerId).ToList();
                var unmatchedTxForCustomerByType = unmatchedTransactionsForCustomer.Where(x => x.TransactionType == "TI").ToList();
                var unmmatchedTxForCustomerByTypeAndYear = unmatchedTxForCustomerByType.Where(x => x.AccountingInformation?.Column2?.DimValue == acadmicYear).ToList();

                //var unmatchedTransactionsForCustomer = unmatchedTransactions
                //    .Where(x => x.Invoice.CustomerId == customerId &&

                //                x.TransactionType == "TI" &&
                //                x.AccountingInformation?.Column2?.DimValue == acadmicYear)  // AcadmicYear //x.PaymentFollowUp.Status == 'N' &&  
                //    .ToList();

                if (unmmatchedTxForCustomerByTypeAndYear.Count == 1)
                {
                    var unmatchedTransaction = unmmatchedTxForCustomerByTypeAndYear.Single();
                    var sequenceNumber = unmatchedTransaction.SequenceNumber;
                    var voucherRef = unmatchedTransaction.TransactionNumber;

                    _logger.LogInformation($"Single unmatched transaction found for customer ID {customerId}: SequenceNumber={sequenceNumber}, TransactionNumber={voucherRef}");
                    
                    return new CustomerTransaction
                    {
                        CustomerId = customerId,
                        SequenceNumber = sequenceNumber,
                        TransactionNumber = voucherRef,
                        Invoice = unmatchedTransaction.Invoice ?? new TransactionInvoice(),
                        PaymentFollowUp = unmatchedTransaction.PaymentFollowUp ?? new TransactionPaymentFollowUp()
                    };
                }
                else if (unmatchedTransactionsForCustomer.Count == 0)
                {
                    LogNoUnmatchedCustomerToBlob(customerId, unmatchCustomerContainer);
                    _logger.LogWarning($"No unmatched transactions found for customer ID {customerId}");
                }
                else
                {
                    var unmatchedTransactionIds = string.Join(',', unmatchedTransactionsForCustomer.Select(x => x.TransactionNumber));
                    LogMultipleUnmatchedCustomerToBlob(customerId, unmatchedTransactionIds, unmatchCustomerContainer);
                    _logger.LogWarning($"Multiple unmatched transactions found for customer ID {customerId}. Transaction IDs: {unmatchedTransactionIds}");
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error while processing unmatched transactions for customer ID {customerId}: {ex.Message}");
            }
            return null;
        }


        /// <summary>
        /// This function is used for converting decimal value to its negative value.
        /// </summary>
        /// <param name="value">We need to provide value which want to convert in its negative value</param>
        /// <returns> Its return type is decimal, returning negative value</returns>
        decimal GetNegativeValue(decimal value)
        {
            return -value;
        }


        /// <summary>
        /// This function is used for logging NoUnmatchedCustomer details to Blob.
        /// </summary>
        /// <param name="string StudentNumber, string logFilePath, Exception ex">We need to provide 3 parameter to this method</param>
        /// <returns> Its return type is void, not returning any value.</returns>
        /// <exception >    </exception>
        private async Task LogNoUnmatchedCustomerToBlob(string studentId, BlobContainerClient unmatchCustomerContainer)
        {
            try
            {
                await unmatchCustomerContainer.CreateIfNotExistsAsync();
                var unmatchedCustomer = $"NoUnmatchedCustomer details: {JsonConvert.SerializeObject(new { studentId })}";
                var unmatchedMessage = $"No unmatched transactions found for customer ID: {studentId}, {unmatchedCustomer} {Environment.NewLine}";

                string unmatchedFileName = $"{DateTime.UtcNow:yyyyMMdd}_NoUnmatchedCustomer.log";
                BlobClient unmatchedBlobClient = unmatchCustomerContainer.GetBlobClient(unmatchedFileName);
                string existingLog = string.Empty;
                if (await unmatchedBlobClient.ExistsAsync())
                {
                    var downloadResult = await unmatchedBlobClient.DownloadContentAsync();
                    existingLog = downloadResult.Value.Content.ToString();
                }
                string updatedLog = existingLog + unmatchedMessage;

                using (var stream = new MemoryStream(Encoding.UTF8.GetBytes(updatedLog)))
                {
                    await unmatchedBlobClient.UploadAsync(stream, overwrite: true);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error logging NoUnmatchedCustomer for StudentId: {studentId}. Exception: {ex.Message}");
            }
        }


        /// <summary>
        /// This function is used for logging MultipleUnmatchedCustomer details to Blob.
        /// </summary>
        /// <param name="string StudentNumber, string logFilePath, Exception ex">We need to provide 3 parameter to this method</param>
        /// <returns> Its return type is void, not returning any value.</returns>
        /// <exception >    </exception>
        private async Task LogMultipleUnmatchedCustomerToBlob(string studentId, string unmatchedTransactionIds, BlobContainerClient unmatchCustomerContainer)
        {
            try
            {
                await unmatchCustomerContainer.CreateIfNotExistsAsync();
                var UnmatchedCustomer = $"MultipleUnmatchedCustomer details: {JsonConvert.SerializeObject(new { studentId })}";

                var unmatchedMessage = $"Multiple unmatched transactions found for customer ID: {studentId}, {UnmatchedCustomer} {Environment.NewLine}";
                string unmatchedFileName = $"{DateTime.Now:yyyyMMdd}_MultipleUnmatchedCustomer.log";
                BlobClient unmatchedBlobClient = unmatchCustomerContainer.GetBlobClient(unmatchedFileName);
                string existingLog = "";
                if (await unmatchedBlobClient.ExistsAsync())
                {
                    var downloadResult = await unmatchedBlobClient.DownloadContentAsync();
                    existingLog = downloadResult.Value.Content.ToString();
                }
                string updatedLog = existingLog + unmatchedMessage;
                using (var stream = new MemoryStream(Encoding.UTF8.GetBytes(updatedLog)))
                {
                    await unmatchedBlobClient.UploadAsync(stream, overwrite: true);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error logging MultipleUnmatchedCustomer for StudentId: {studentId}. Exception: {ex.Message}");
            }
        }

        public async Task LogSftpToBlob(BlobContainerClient logFileContainer, string message)
        {
            try
            {
                var logMessage = message + Environment.NewLine; 
                string logFileName = $"{DateTime.Now:yyyyMMdd}_SftpTransfer.log";

                BlobClient logBlobClient = logFileContainer.GetBlobClient(logFileName);
                string existingLog = "";
                if (await logBlobClient.ExistsAsync())
                {
                    var downloadResult = await logBlobClient.DownloadContentAsync();
                    existingLog = downloadResult.Value.Content.ToString();
                }
                string updatedLog = existingLog + logMessage;
                using (var stream = new MemoryStream(Encoding.UTF8.GetBytes(updatedLog)))
                {
                    await logBlobClient.UploadAsync(stream, overwrite: true);
                }
            }
            catch (Exception logEx)
            {
                Console.WriteLine($"Error logging error for processing data. Exception: {logEx.Message}");
            }
        }


        /// <summary>
        /// This function is used for logging successful iterations to Blob.
        /// </summary>
        /// <param name="string StudentId, string logFilePath, Exception ex">We need to provide 3 parameter to this method</param>
        /// <returns> Its return type is void, not returning any value.</returns>
        /// <exception >    </exception>
        private async Task LogSuccessToBlob(List<Gl07Row>? gl07Output, BlobContainerClient logFileContainer, string? totalCount)
        {
            try
            {
                string logFileName = $"{DateTime.Now:yyyyMMdd}_PaySuccess.log";
                BlobClient logBlobClient = logFileContainer.GetBlobClient(logFileName);
                StringBuilder logContent = new StringBuilder();
                if (await logBlobClient.ExistsAsync())
                {
                    var downloadResult = await logBlobClient.DownloadContentAsync();
                    logContent.Append(downloadResult.Value.Content.ToString());
                }
                logContent.AppendLine(totalCount);
                if (gl07Output != null && gl07Output.Any())
                {
                    foreach (var student in gl07Output)
                    {
                        var logMessage = $"Success: Processed Payment record for: {student.AparId}, Payment details: {JsonConvert.SerializeObject(new { student.AparId, student.Amount, student.TransDate })}{Environment.NewLine}";

                        logContent.AppendLine(logMessage);
                    }
                    Console.WriteLine($"Logging of Payment's success case has been done");
                }
                using (var stream = new MemoryStream(Encoding.UTF8.GetBytes(logContent.ToString())))
                {
                    await logBlobClient.UploadAsync(stream, overwrite: true);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error logging payment for Student. Exception: {ex.Message}");
            }
        }


        /// <summary>
        /// This function is used for logging error which may occur during execution of application.
        /// </summary>
        /// <param name="string studentId, string logFilePath, Exception ex">We need to provide 3 parameter to this method</param>
        /// <returns> Its return type is void, not returning any value.</returns>
        /// <exception > This method itself used for logging error/exception so its not going to use for logging its own exception</exception>
        private async Task LogErrorToBlob(string studentId, string? campusCode, decimal? amount, BlobContainerClient logFileContainer, Exception ex)
        {
            try
            {
                var logMessage = $"Error occurred during payment processing for studentId: {studentId}, CampusCode: {campusCode}, Amount: {amount}, Exception: {ex.Message}, StackTrace: {ex.StackTrace}{Environment.NewLine}";
                string logFileName = $"{DateTime.Now:yyyyMMdd}_PayError.log";                
                BlobClient logBlobClient = logFileContainer.GetBlobClient(logFileName);
                string existingLog = "";
                if (await logBlobClient.ExistsAsync())
                {
                    var downloadResult = await logBlobClient.DownloadContentAsync();
                    existingLog = downloadResult.Value.Content.ToString();
                }
                string updatedLog = existingLog + logMessage;
                using (var stream = new MemoryStream(Encoding.UTF8.GetBytes(updatedLog)))
                {
                    await logBlobClient.UploadAsync(stream, overwrite: true);
                }
            }
            catch (Exception logEx)
            {
                Console.WriteLine($"Error logging error for studentId: {studentId}. Exception: {logEx.Message}");
            }
        }


        /// <summary>
        /// This function is used for logging error which may occur during execution of application.
        /// </summary>
        /// <param name="string studentId, string logFilePath, Exception ex">We need to provide 3 parameter to this method</param>
        /// <returns> Its return type is void, not returning any value</returns>
        /// <exception> This method itself used for logging error/exception so its not going to use for logging its own exception</exception>
        public async Task LogErrorToBlob(BlobContainerClient logFileContainer, Exception? ex)
        {
            try
            {
                var logMessage = $"Exception: {ex.Message}, StackTrace: {ex.StackTrace}{Environment.NewLine}";
                string logFileName = $"{DateTime.Now:yyyyMMdd}_error.log";
                
                BlobClient logBlobClient = logFileContainer.GetBlobClient(logFileName);
                string existingLog = "";
                if (await logBlobClient.ExistsAsync())
                {
                    var downloadResult = await logBlobClient.DownloadContentAsync();
                    existingLog = downloadResult.Value.Content.ToString();
                }
                string updatedLog = existingLog + logMessage;
                using (var stream = new MemoryStream(Encoding.UTF8.GetBytes(updatedLog)))
                {
                    await logBlobClient.UploadAsync(stream, overwrite: true);
                }
            }
            catch (Exception logEx)
            {
                Console.WriteLine($"Error logging error for processing data. Exception: {logEx.Message}");
            }
        }
    }
}
