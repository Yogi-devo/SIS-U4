﻿using Azure.Storage.Blobs;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using PaymentFunction.Config;
using Renci.SshNet;


namespace PaymentFunction.Services
{
    public class Unit4SftpClient(IOptions<SftpConfig> sftpConfig, IConfiguration configuration) : Interfaces.ISftpClient
    {
        public void UploadFile(string sourceFilePath, string sourceFileName)
        {
            var blobConnectionString = configuration["Storage:StorageAccountConnectionString"];
            var blobContainerName = configuration["File:CreateFileContainer"];
            var settings = sftpConfig.Value;
            // Enable SFTP logging to debug issues
            var connectionInfo = new ConnectionInfo(
                settings.Hostname,
                settings.Port,
                settings.Username,
                new PasswordAuthenticationMethod(settings.Username, settings.Password)
            );
            using var sftpClient = new SftpClient(connectionInfo);

            try
            {
                sftpClient.Connect();

                if (sftpClient.IsConnected)
                {
                    Stream fileStream;

                    if (Uri.IsWellFormedUriString(sourceFilePath, UriKind.Absolute))
                    {
                        var blobClient = new BlobServiceClient(blobConnectionString);
                        var containerClient = blobClient.GetBlobContainerClient(blobContainerName);
                        var blobName = Path.GetFileName(sourceFilePath);

                        var blob = containerClient.GetBlobClient(blobName);
                        fileStream = new MemoryStream();
                        blob.DownloadTo(fileStream);
                        fileStream.Position = 0;
                    }
                    else
                    {
                        fileStream = File.OpenRead(sourceFilePath);
                    }
                    sftpClient.UploadFile(fileStream, sourceFileName);
                    Console.WriteLine($"File from {sourceFilePath} transferred successfully through SFTP");
                    fileStream.Dispose();
                }
                else
                {
                    Console.WriteLine("Unable to connect to SFTP");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"SFTP connection error: {ex.Message}");
                throw;
            }
            finally
            {
                sftpClient.Disconnect();
            }
        }





        //public void UploadFile(string sourceFilePath, string sourceFileName)
        //{
        //    try
        //    {
        //        var settings = sftpConfig.Value;
        //        using var sftpClient = new SftpClient(settings.Hostname, settings.Port, settings.Username, settings.Password);
        //        sftpClient.Connect();
        //        if (sftpClient.IsConnected)
        //        {
        //            using var fileStream = File.OpenRead(sourceFilePath);
        //            sftpClient.UploadFile(fileStream, sourceFileName);
        //            Console.WriteLine($"{fileStream} transferd successfully");
        //        }
        //        else
        //        {
        //            Console.WriteLine("Unable to connect to SFTP");
        //        }
        //    }
        //    catch (Exception ex)
        //    {

        //        Console.WriteLine($"An error occurred while SFTP execution: {ex.Message}");
        //    }

        //}

    }
}
