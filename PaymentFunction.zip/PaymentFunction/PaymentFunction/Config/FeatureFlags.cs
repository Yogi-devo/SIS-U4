﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PaymentFunction.Config
{
    public class FeatureFlags
    {
        public bool FunctionEnabled { get; set; }
    }
}
