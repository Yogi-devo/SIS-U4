﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PaymentFunction.Config
{
    public class Gl07Values
    {
        public required string BaseBatchId { get; set; }
        public required char AparType { get; set; }
        public required string Interface { get; set; }
        public required string VoucherType { get; set; }
        public required string Client { get; set; }
        public required string TaxCode { get; set; }
        public required char Status { get; set; }
        public required string TransTypeHeader { get; set; }
        public required string TransTypeValue { get; set; }
        public required string AccountDebt { get; set; }
        public required string AccountBank { get; set; }
    }
}
