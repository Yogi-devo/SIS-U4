﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PaymentFunction.Config
{
    public class SftpConfig
    {
        public required string Hostname { get; set; }
        public int Port { get; set; } = 22;
        public required string Username { get; set; }
        public required string Password { get; set; }
    }
}
