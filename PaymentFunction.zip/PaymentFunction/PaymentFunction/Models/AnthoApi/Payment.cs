﻿using Newtonsoft.Json;
using System.Text.Json.Serialization;

namespace PaymentFunction.Models.AnthoApi
{
    public class PaymentApiResponse
    {
        [JsonPropertyName("value")]
        public List<PaymentReceipt> Value { get; set; }
    }
    public class PaymentReceipt
    {
        public string ReceiptNumber { get; set; }
        public string Type { get; set; } 
        public string Source { get; set; }
        public string PaymentType { get; set; }
        public decimal AmountPaid { get; set; }
        public decimal TransactionAmount { get; set; }
        public string CheckNumber { get; set; }
        public string Reference { get; set; }
        public string? Description { get; set; }

        [JsonProperty("StudentId")]
        public int StudentId { get; set; }
        public int Id { get; set; }
        public int AcademicYearSequence { get; set; }
        public int? TransactionNumber { get; set; }
        public DateTimeOffset? ReceiptPrintedDate { get; set; }
        public DateTime? PostDate { get; set; }
        public Student? Student { get; set; }
        public BankAccount? BankAccount { get; set; }
        public StudentEnrollmentPeriod? StudentEnrollmentPeriod { get; set; }
        public List<ExtendedProperties>? ExtendedProperties { get; set; }
        public string? BillingTransactionCode { get; set; }
        public Term? Term { get; set; }
        public Campus? Campus { get; set; } // Adjusted to match object structure
        //public DateTimeOffset? TransactionDate { get; set; }
        public DateTime? TransactionDate { get; set; }
        public DateTime? CreatedDateTime { get; set; }

        public StudentAward? StudentAward { get; set; }

    }

    public class StudentEnrollmentPeriod
    {
        public int Id { get; set; }
        public string? EnrollmentNumber { get; set; }
        public decimal? AccountReceivableBalance { get; set; }
        public List<AcademicYears>? AcademicYears { get; set; }
        public GradeScale GradeScale { get; set; }
    }
    public class AcademicYears
    {
        public int Id { get; set; }
        public int AcademicYearId { get; set; }
        public int Sequence { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string? FirstAwardYear { get; set; }

    }
    public class Term
    {
        public int Id { get; set; }
        public string? Name { get; set; }
    }
    public class GradeScale
    {
        public string Name { get; set; }
    }
    public class Campus
    {
        public int Id { get; set; }
        public string? Name { get; set; }
        public string? Code { get; set; }
    }

    public class ExtendedProperties
    {
        public string? Name { get; set; }
        public string? StringValue { get; set; }
    }
    public class Student
    {
        public string? Id { get; set; }
        public string? StudentNumber { get; set; }
        public decimal ArBalance { get; set; }
        public List<AgencyBranches>? AgencyBranches { get; set; }
    }

    public class AgencyBranches
    {
        public AgencyBranch? AgencyBranch { get; set; }
    }
    public class AgencyBranch
    {
        public int Id { get; set; }
        public string? Name { get; set; }
        public Agency? Agency { get; set; }
    }
    public class Agency
    {
        public int? Id { get; set; }
        public string? Code { get; set; }
        public string? Name { get; set; }
    }
    public class BankAccount
    {
        public string? AccountName { get; set; }
        public string? Currency { get; set; }
        public string? GlCreditAccount { get; set; }
        public string? GlDebitAccount { get; set; }
    }
    public class StudentAward
    {
        public FundSource? FundSource { get; set; }
    }
    public class FundSource
    {
        public string? Code { get; set; }
        public string? Name { get; set; }
    }
}
