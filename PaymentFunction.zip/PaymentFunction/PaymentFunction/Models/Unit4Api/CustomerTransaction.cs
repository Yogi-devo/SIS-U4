﻿using Newtonsoft.Json;

namespace PaymentFunction.Models.Unit4Api
{    
    public class TransactionResult
    {

    }
    public class CustomerTransaction
    {
        [JsonProperty("customerId")]
        public string? CustomerId { get; set; }

        [JsonProperty("transactionNumber")]
        public long? TransactionNumber { get; set; }

        [JsonProperty("sequenceNumber")]
        public int? SequenceNumber { get; set; } 

        [JsonProperty("invoice")]
        public required TransactionInvoice Invoice { get; set; }

        [JsonProperty("paymentFollowUp")]
        public required TransactionPaymentFollowUp PaymentFollowUp { get; set; }
        
        [JsonProperty("accountingInformation")]
        public AccountingInformation? AccountingInformation { get; set; }
        [JsonProperty("amounts")]
        public Amounts? Amount { get; set; }
        [JsonProperty("transactionType")]
        public string? TransactionType { get; set; }
    }

    public class Amounts
    {
        [JsonProperty("amountPaid")]
        public int? AmountPaid { get; set; }
        //[JsonProperty("amountPaid")]
        //public int? TransactionAmount { get; set; }
    }
    public class TransactionInvoice
    {
        [JsonProperty("customerId")]
        public string? CustomerId { get; set; }
    }

    public class TransactionPaymentFollowUp
    {
        [JsonProperty("status")]
        public char? Status { get; set; }
    }

    public class AccountingInformation
    {
        [JsonProperty("account")]
        public string? Account { get; set; }

        [JsonProperty("column3")]
        public Column3? Column3 { get; set; }
        [JsonProperty("column2")]
        public Column3? Column2 { get; set; }
    }

    public class Column3
    {
        [JsonProperty("attributeId")]
        public string? AttributeId { get; set; }

        [JsonProperty("dimValue")]
        public string? DimValue { get; set; }
    }
}
