﻿using Newtonsoft.Json;

namespace PaymentFunction.Models.Unit4Api
{
    public class Payment
    {
        [JsonProperty("bankAccount")]
        public string? BankAccount { get; set; }

        [JsonProperty("bankClearingCode")]
        public string? BankClearingCode { get; set; }

        [JsonProperty("debtCollectionCode")]
        public string? DebtCollectionCode { get; set; }

        [JsonProperty("expiryDate")]
        public DateTime? ExpiryDate { get; set; }

        [JsonProperty("iban")]
        public string? Iban { get; set; }

        [JsonProperty("otherAccount")]
        public string? OtherAccount { get; set; }

        [JsonProperty("payMethod")]
        public string? PayMethod { get; set; }

        [JsonProperty("payRecipient")]
        public string? PayRecipient { get; set; }

        [JsonProperty("postalAccount")]
        public string? PostalAccount { get; set; }

        [JsonProperty("status")]
        public string? Status { get; set; }

        [JsonProperty("swift")]
        public string? Swift { get; set; }

        [JsonProperty("notificationMessages")]
        public NotificationMessages? NotificationMessages { get; set; }
    }
}
