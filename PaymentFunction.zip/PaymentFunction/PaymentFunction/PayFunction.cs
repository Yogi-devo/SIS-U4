using System;
using Azure.Storage.Blobs;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using PaymentFunction.Config;
using PaymentFunction.Interfaces;

namespace PaymentFunction
{
    public class PayFunction
    {
        private readonly ILogger _logger;
        private readonly IConfiguration _configuration;        
        private readonly BlobServiceClient _blobServiceClient;
        private readonly BlobContainerClient _logFileContainer;
        private readonly IUnit4ApiService _unit4ApiService;

        public PayFunction(ILoggerFactory loggerFactory, IConfiguration configuration, IUnit4ApiService unit4ApiService, Interfaces.ISftpClient sftpClient, IOptions<FeatureFlags> featureFlags)
        {
            _logger = loggerFactory.CreateLogger<PayFunction>();
            _unit4ApiService = unit4ApiService;
            _configuration = configuration;            
            _blobServiceClient = new BlobServiceClient(configuration["Storage:StorageAccountConnectionString"]);
            _logFileContainer = _blobServiceClient.GetBlobContainerClient(configuration["Log:LogFileContainer"]);
        }

        [Function("PayFunction")]
        public async Task RunAsync([TimerTrigger("%FunctionSchedule%", RunOnStartup = false)] TimerInfo myTimer)
        {                    
           
            try
            {
                DateTime? lastRunTime = myTimer.ScheduleStatus?.Last;

                DateTime formattedLastRunTime = DateTime.MinValue;

                if (lastRunTime.HasValue)
                {
                    //--- For running locally using Visual Studio ---

                    //TimeZoneInfo indiaTimeZone = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
                    //DateTime istTime = DateTime.SpecifyKind(lastRunTime.Value, DateTimeKind.Unspecified);
                    //DateTime utcTime = TimeZoneInfo.ConvertTimeToUtc(istTime, indiaTimeZone);
                    //TimeZoneInfo newYorkTimeZone = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
                    //formattedLastRunTime = TimeZoneInfo.ConvertTimeFromUtc(utcTime, newYorkTimeZone);

                    //--- For deployment at azure ---

                    DateTime utcTime = DateTime.SpecifyKind(lastRunTime.Value, DateTimeKind.Utc);
                    TimeZoneInfo newYorkTimeZone = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
                    formattedLastRunTime = TimeZoneInfo.ConvertTimeFromUtc(utcTime, newYorkTimeZone);

                    Console.WriteLine($"UTC Time: {utcTime}");
                    Console.WriteLine($"New York Time: {formattedLastRunTime}");
                }
                _logger.LogInformation($"Payment function execution started at: {DateTime.Now}");
                await _unit4ApiService.FetchPaymentFromAnthology(formattedLastRunTime);
                _logger.LogInformation($"Payment function execution completed at: {DateTime.Now}");
            }
            catch (Exception)
            {

                throw;
            }
            if (myTimer.ScheduleStatus is not null)
            {
                _logger.LogInformation($"Next timer schedule at: {myTimer.ScheduleStatus.Next}");
                _logger.LogInformation($"Current time: {DateTime.Now}");
                _logger.LogInformation($"Last execution: {myTimer.ScheduleStatus.Last}");               
                _logger.LogInformation($"Last updated: {myTimer.ScheduleStatus.LastUpdated}");
            }
        }
    }
}
